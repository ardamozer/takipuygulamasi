using System;
using System.Globalization;
using System.Windows.Data;

namespace ActivityTracker.UI.Mvvm
{
    /// <summary>CurrentSection, ConverterParameter ile eşleşiyorsa true döner (nav vurgusu için).</summary>
    public class SectionActiveConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return string.Equals(value as string, parameter as string, StringComparison.Ordinal);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // RadioButton'dan geri yazımı yok sayıyoruz; navigasyon Command ile yapılır.
            return Binding.DoNothing;
        }
    }
}
