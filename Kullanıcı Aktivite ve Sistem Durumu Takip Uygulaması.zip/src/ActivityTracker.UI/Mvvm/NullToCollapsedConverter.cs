using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace ActivityTracker.UI.Mvvm
{
    /// <summary>Değer null/boş ise Collapsed, doluysa Visible döndürür.</summary>
    public class NullToCollapsedConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var empty = value == null || (value is string s && string.IsNullOrWhiteSpace(s));
            return empty ? Visibility.Collapsed : Visibility.Visible;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
