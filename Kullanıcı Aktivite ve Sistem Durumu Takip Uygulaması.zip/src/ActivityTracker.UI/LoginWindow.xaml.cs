using System.Windows;
using ActivityTracker.UI.Api;
using ActivityTracker.UI.ViewModels;

namespace ActivityTracker.UI
{
    public partial class LoginWindow : Window
    {
        private readonly LoginViewModel _viewModel;

        /// <summary>Giriş başarılıysa hazır istemci; iptal/başarısızsa null.</summary>
        public BackendApiClient Client { get; private set; }

        public LoginWindow(PanelSettings settings)
        {
            InitializeComponent();
            _viewModel = new LoginViewModel(settings);
            _viewModel.LoginSucceeded += OnLoginSucceeded;
            DataContext = _viewModel;
            Loaded += (s, e) => UsernameBox.Focus();
        }

        private async void OnLoginClick(object sender, RoutedEventArgs e)
        {
            await _viewModel.LoginAsync(PasswordBox.Password);
        }

        private void OnLoginSucceeded(BackendApiClient client)
        {
            Client = client;
            DialogResult = true;
            Close();
        }
    }
}
