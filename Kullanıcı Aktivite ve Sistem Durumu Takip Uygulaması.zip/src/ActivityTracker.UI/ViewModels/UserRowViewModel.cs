using System;
using System.Windows.Media;
using ActivityTracker.Domain.Api;
using ActivityTracker.UI.Mvvm;

namespace ActivityTracker.UI.ViewModels
{
    /// <summary>Yönetici kullanıcı listesinde tek bir kullanıcı kartı.</summary>
    public class UserRowViewModel
    {
        public string UserName { get; set; }
        public string DisplayName { get; set; }
        public string Machine { get; set; }
        public string StatusText { get; set; }
        public Brush StatusBrush { get; set; }
        public string LastActivity { get; set; }
        public string Initial { get; set; }

        /// <summary>Kendi hesabı için silme gizlenir (kilitlenmeyi önler).</summary>
        public bool CanDelete { get; set; }

        public RelayCommand SelectCommand { get; set; }
        public RelayCommand DeleteCommand { get; set; }

        public static UserRowViewModel From(UserSummaryDto dto, Action<string> onSelect,
            Action<string> onDelete, string currentUser)
        {
            return new UserRowViewModel
            {
                UserName = dto.UserName,
                DisplayName = string.IsNullOrWhiteSpace(dto.DisplayName) ? dto.UserName : dto.DisplayName,
                Machine = string.IsNullOrWhiteSpace(dto.Machine) ? "-" : dto.Machine,
                StatusText = dto.Status ?? "-",
                StatusBrush = BrushFor(dto.Status),
                LastActivity = dto.LastActivity?.ToString("dd.MM HH:mm") ?? "-",
                Initial = string.IsNullOrWhiteSpace(dto.UserName)
                    ? "?" : dto.UserName.Trim().Substring(0, 1).ToUpperInvariant(),
                CanDelete = !string.Equals(dto.UserName, currentUser, StringComparison.OrdinalIgnoreCase),
                SelectCommand = new RelayCommand(() => onSelect(dto.UserName)),
                DeleteCommand = new RelayCommand(() => onDelete(dto.UserName))
            };
        }

        private static Brush BrushFor(string status)
        {
            string key;
            switch (status)
            {
                case "Aktif": key = "SuccessBrush"; break;
                case "Pasif (Boşta)": key = "WarningBrush"; break;
                case "Ekran Kilitli": key = "NavyBrush"; break;
                case "Uyku Modu": key = "TextSecondaryBrush"; break;
                case "Çevrimdışı": key = "DangerBrush"; break;
                default: key = "TextSecondaryBrush"; break;
            }
            var app = System.Windows.Application.Current;
            return (app?.TryFindResource(key) as Brush) ?? Brushes.Gray;
        }
    }
}
