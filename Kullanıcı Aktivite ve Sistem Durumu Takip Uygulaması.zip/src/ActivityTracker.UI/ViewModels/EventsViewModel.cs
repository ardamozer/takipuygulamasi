using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using ActivityTracker.UI.Api;
using ActivityTracker.UI.Mvvm;

namespace ActivityTracker.UI.ViewModels
{
    /// <summary>Seçilen güne ait olay geçmişi (backend'den çekilir).</summary>
    public class EventsViewModel : ViewModelBase
    {
        private readonly BackendApiClient _client;
        private readonly Func<string> _targetUser;

        public EventsViewModel(BackendApiClient client, Func<string> targetUser)
        {
            _client = client;
            _targetUser = targetUser;
            _selectedDate = DateTime.Today;
            RefreshCommand = new RelayCommand(() => _ = LoadAsync());
        }

        public ObservableCollection<EventRowViewModel> Events { get; } =
            new ObservableCollection<EventRowViewModel>();

        private DateTime _selectedDate;
        public DateTime SelectedDate
        {
            get => _selectedDate;
            set { if (SetProperty(ref _selectedDate, value)) _ = LoadAsync(); }
        }

        private int _count;
        public int Count { get => _count; set => SetProperty(ref _count, value); }

        public RelayCommand RefreshCommand { get; }

        public async Task LoadAsync()
        {
            try
            {
                var list = await _client.GetEventsAsync(_targetUser?.Invoke(), _selectedDate);
                Events.Clear();
                foreach (var ev in list)
                    Events.Add(EventRowViewModel.From(ev));
                Count = Events.Count;
            }
            catch
            {
                Events.Clear();
                Count = 0;
            }
        }
    }
}
