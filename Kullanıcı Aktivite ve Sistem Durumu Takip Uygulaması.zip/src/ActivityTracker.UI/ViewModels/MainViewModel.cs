using System;
using ActivityTracker.UI.Api;
using ActivityTracker.UI.Mvvm;

namespace ActivityTracker.UI.ViewModels
{
    /// <summary>Ana pencere ViewModel'i: rol bazlı navigasyon + (yönetici) kullanıcı seçimi.</summary>
    public class MainViewModel : ViewModelBase
    {
        private readonly BackendApiClient _client;

        /// <summary>Kullanıcı oturumu kapatmak istediğinde tetiklenir (App yeniden giriş gösterir).</summary>
        public event Action LogoutRequested;

        public MainViewModel(BackendApiClient client, PanelSettings settings)
        {
            _client = client;
            IsAdmin = client.IsAdmin;
            UserName = string.IsNullOrWhiteSpace(client.DisplayName) ? client.Username : client.DisplayName;
            UserInitial = string.IsNullOrWhiteSpace(UserName) ? "?" : UserName.Trim().Substring(0, 1).ToUpperInvariant();
            RoleLabel = IsAdmin ? "Yönetici" : "Kullanıcı";

            // Yönetici başka kullanıcının verisine bakabilir; normal kullanıcı hep kendi verisi (null).
            Func<string> target = () => _targetUser;

            Dashboard = new DashboardViewModel(client, target);
            Report = new DailyReportViewModel(client, target);
            Events = new EventsViewModel(client, target);
            Settings = new SettingsViewModel(client, settings, () => LogoutRequested?.Invoke());
            if (IsAdmin)
                Users = new UsersViewModel(client, SelectUser);

            NavigateCommand = new RelayCommand(p => Navigate(p as string));

            // Yönetici kullanıcı listesiyle, normal kullanıcı kendi paneliyle başlar.
            if (IsAdmin) Navigate("users");
            else Navigate("dashboard");
        }

        public bool IsAdmin { get; }
        public string UserName { get; }
        public string UserInitial { get; }
        public string RoleLabel { get; }

        public DashboardViewModel Dashboard { get; }
        public DailyReportViewModel Report { get; }
        public EventsViewModel Events { get; }
        public SettingsViewModel Settings { get; }
        public UsersViewModel Users { get; }

        /// <summary>Yönetici için görüntülenen kullanıcı; normal kullanıcıda hep null (kendi verisi).</summary>
        private string _targetUser;

        private object _currentViewModel;
        public object CurrentViewModel { get => _currentViewModel; set => SetProperty(ref _currentViewModel, value); }

        private string _currentSection;
        public string CurrentSection { get => _currentSection; set => SetProperty(ref _currentSection, value); }

        private string _title = "Gösterge Paneli";
        public string Title { get => _title; set => SetProperty(ref _title, value); }

        public RelayCommand NavigateCommand { get; }

        /// <summary>Yönetici bir kullanıcı seçtiğinde o kullanıcının paneline geçer.</summary>
        private void SelectUser(string userName)
        {
            _targetUser = userName;
            Navigate("dashboard");
        }

        private void Navigate(string section)
        {
            if (string.IsNullOrEmpty(section)) return;
            switch (section)
            {
                case "dashboard":
                    _ = Dashboard.RefreshAsync(); CurrentViewModel = Dashboard;
                    Title = TitleWithSubject("Gösterge Paneli"); break;
                case "report":
                    _ = Report.LoadAsync(); CurrentViewModel = Report;
                    Title = TitleWithSubject("Çalışma Raporu"); break;
                case "events":
                    _ = Events.LoadAsync(); CurrentViewModel = Events;
                    Title = TitleWithSubject("Olay Geçmişi"); break;
                case "users":
                    if (Users == null) return;
                    _targetUser = null;             // listeye dönünce kendi/boş hedefe sıfırla
                    _ = Users.LoadAsync(); CurrentViewModel = Users; Title = "Kullanıcılar"; break;
                case "settings":
                    CurrentViewModel = Settings; Title = "Ayarlar"; break;
            }
            CurrentSection = section;
        }

        private string TitleWithSubject(string baseTitle)
        {
            return (IsAdmin && _targetUser != null) ? baseTitle + " — " + _targetUser : baseTitle;
        }
    }
}
