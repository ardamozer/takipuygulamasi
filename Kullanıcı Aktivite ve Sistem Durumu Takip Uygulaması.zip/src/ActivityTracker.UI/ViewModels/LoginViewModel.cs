using System;
using System.Threading.Tasks;
using ActivityTracker.UI.Api;
using ActivityTracker.UI.Mvvm;

namespace ActivityTracker.UI.ViewModels
{
    /// <summary>Giriş ekranı: kullanıcı adı/parola + backend adresi.</summary>
    public class LoginViewModel : ViewModelBase
    {
        private readonly PanelSettings _settings;

        /// <summary>Giriş başarılı olduğunda hazır istemciyle tetiklenir.</summary>
        public event Action<BackendApiClient> LoginSucceeded;

        public LoginViewModel(PanelSettings settings)
        {
            _settings = settings;
            _backendUrl = settings.BackendUrl;
        }

        private string _username;
        public string Username { get => _username; set => SetProperty(ref _username, value); }

        private string _backendUrl;
        public string BackendUrl { get => _backendUrl; set => SetProperty(ref _backendUrl, value); }

        private string _error;
        public string Error { get => _error; set => SetProperty(ref _error, value); }

        private bool _isBusy;
        public bool IsBusy { get => _isBusy; set { if (SetProperty(ref _isBusy, value)) OnPropertyChanged(nameof(CanInteract)); } }

        public bool CanInteract => !_isBusy;

        /// <summary>Parola PasswordBox'tan koda gelir (güvenlik için bağlanmaz).</summary>
        public async Task LoginAsync(string password)
        {
            if (string.IsNullOrWhiteSpace(Username))
            {
                Error = "Kullanıcı adı gerekli.";
                return;
            }

            Error = null;
            IsBusy = true;
            try
            {
                _settings.BackendUrl = (BackendUrl ?? string.Empty).Trim();
                _settings.Save();

                var client = new BackendApiClient(_settings.BackendUrl);
                bool ok;
                try
                {
                    ok = await client.LoginAsync(Username.Trim(), password ?? string.Empty);
                }
                catch (InvalidOperationException ex)
                {
                    // Backend ulaşıldı ama hatalı yanıt verdi (503/500 vb.).
                    Error = ex.Message;
                    return;
                }
                catch
                {
                    Error = "Backend'e bağlanılamadı. Adresi ve backend'in çalıştığını kontrol edin.";
                    return;
                }

                if (!ok)
                {
                    Error = "Kullanıcı adı veya parola hatalı.";
                    return;
                }

                LoginSucceeded?.Invoke(client);
            }
            finally
            {
                IsBusy = false;
            }
        }
    }
}
