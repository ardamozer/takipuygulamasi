using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using ActivityTracker.Domain.Models;
using ActivityTracker.UI.Api;
using ActivityTracker.UI.Helpers;
using ActivityTracker.UI.Mvvm;

namespace ActivityTracker.UI.ViewModels
{
    /// <summary>Günlük ve haftalık çalışma raporu (backend'den çekilir).</summary>
    public class DailyReportViewModel : ViewModelBase
    {
        private const double MaxBarHeight = 150.0;

        private readonly BackendApiClient _client;
        private readonly Func<string> _targetUser;

        public DailyReportViewModel(BackendApiClient client, Func<string> targetUser)
        {
            _client = client;
            _targetUser = targetUser;
            _selectedDate = DateTime.Today;

            PrevDayCommand = new RelayCommand(() => SelectedDate = SelectedDate.AddDays(-1));
            NextDayCommand = new RelayCommand(() => SelectedDate = SelectedDate.AddDays(1));
            TodayCommand = new RelayCommand(() => SelectedDate = DateTime.Today);
        }

        public ObservableCollection<DayBarViewModel> WeekDays { get; } =
            new ObservableCollection<DayBarViewModel>();

        private DateTime _selectedDate;
        public DateTime SelectedDate
        {
            get => _selectedDate;
            set { if (SetProperty(ref _selectedDate, value)) _ = LoadAsync(); }
        }

        private string _dateHeader;
        public string DateHeader { get => _dateHeader; set => SetProperty(ref _dateHeader, value); }

        private string _totalTime = "0 sn";
        public string TotalTime { get => _totalTime; set => SetProperty(ref _totalTime, value); }

        private string _activeTime = "0 sn";
        public string ActiveTime { get => _activeTime; set => SetProperty(ref _activeTime, value); }

        private string _idleTime = "0 sn";
        public string IdleTime { get => _idleTime; set => SetProperty(ref _idleTime, value); }

        private string _lockedTime = "0 sn";
        public string LockedTime { get => _lockedTime; set => SetProperty(ref _lockedTime, value); }

        private string _firstLogin = "-";
        public string FirstLogin { get => _firstLogin; set => SetProperty(ref _firstLogin, value); }

        private string _lastActivity = "-";
        public string LastActivity { get => _lastActivity; set => SetProperty(ref _lastActivity, value); }

        private double _activePercent;
        public double ActivePercent { get => _activePercent; set => SetProperty(ref _activePercent, value); }

        private double _idlePercent;
        public double IdlePercent { get => _idlePercent; set => SetProperty(ref _idlePercent, value); }

        private double _lockedPercent;
        public double LockedPercent { get => _lockedPercent; set => SetProperty(ref _lockedPercent, value); }

        private string _weekRange;
        public string WeekRange { get => _weekRange; set => SetProperty(ref _weekRange, value); }

        public RelayCommand PrevDayCommand { get; }
        public RelayCommand NextDayCommand { get; }
        public RelayCommand TodayCommand { get; }

        public async Task LoadAsync()
        {
            DateHeader = _selectedDate.ToString("dd MMMM yyyy, dddd");
            var target = _targetUser?.Invoke();

            try
            {
                var report = await _client.GetReportAsync(target, _selectedDate);

                TotalTime = TimeFormat.Humanize(report.TotalTime);
                ActiveTime = TimeFormat.Humanize(report.ActiveTime);
                IdleTime = TimeFormat.Humanize(report.IdleTime);
                LockedTime = TimeFormat.Humanize(report.LockedTime);
                FirstLogin = TimeFormat.ClockOrDash(report.FirstLogin);
                LastActivity = TimeFormat.ClockOrDash(report.LastActivity);

                var total = report.TotalTime.TotalSeconds;
                ActivePercent = total <= 0 ? 0 : report.ActiveTime.TotalSeconds / total * 100.0;
                IdlePercent = total <= 0 ? 0 : report.IdleTime.TotalSeconds / total * 100.0;
                LockedPercent = total <= 0 ? 0 : report.LockedTime.TotalSeconds / total * 100.0;

                await LoadWeekAsync(target);
            }
            catch
            {
                // Bağlantı hatasında sessizce boş bırak (panel çökmesin).
            }
        }

        private async Task LoadWeekAsync(string target)
        {
            var monday = StartOfWeek(_selectedDate);
            WeekRange = string.Format("{0:dd MMM} - {1:dd MMM}", monday, monday.AddDays(6));

            IList<DailyReport> reports = await _client.GetWeekAsync(target, monday);

            WeekDays.Clear();
            double maxHours = 0.01;
            foreach (var r in reports)
                if (r.TotalTime.TotalHours > maxHours) maxHours = r.TotalTime.TotalHours;

            var dayNames = new[] { "Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz" };
            for (int i = 0; i < reports.Count; i++)
            {
                var r = reports[i];
                WeekDays.Add(new DayBarViewModel
                {
                    DayLabel = i < dayNames.Length ? dayNames[i] : r.Date.ToString("ddd"),
                    DateLabel = r.Date.ToString("dd.MM"),
                    TotalText = TimeFormat.Humanize(r.TotalTime),
                    BarHeight = Math.Max(2.0, r.TotalTime.TotalHours / maxHours * MaxBarHeight),
                    IsToday = r.Date == DateTime.Today
                });
            }
        }

        private static DateTime StartOfWeek(DateTime date)
        {
            int diff = (7 + (int)date.DayOfWeek - (int)DayOfWeek.Monday) % 7;
            return date.Date.AddDays(-diff);
        }
    }
}
