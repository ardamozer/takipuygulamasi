using System;
using ActivityTracker.UI.Api;
using ActivityTracker.UI.Mvvm;

namespace ActivityTracker.UI.ViewModels
{
    /// <summary>Ayarlar: oturum bilgisi, backend adresi ve oturumu kapatma.</summary>
    public class SettingsViewModel : ViewModelBase
    {
        public SettingsViewModel(BackendApiClient client, PanelSettings settings, Action onLogout)
        {
            UserName = client.Username;
            DisplayName = string.IsNullOrWhiteSpace(client.DisplayName) ? client.Username : client.DisplayName;
            RoleLabel = client.IsAdmin ? "Yönetici" : "Kullanıcı";
            BackendUrl = settings.BackendUrl;
            LogoutCommand = new RelayCommand(() => onLogout?.Invoke());
        }

        public string UserName { get; }
        public string DisplayName { get; }
        public string RoleLabel { get; }
        public string BackendUrl { get; }

        public RelayCommand LogoutCommand { get; }
    }
}
