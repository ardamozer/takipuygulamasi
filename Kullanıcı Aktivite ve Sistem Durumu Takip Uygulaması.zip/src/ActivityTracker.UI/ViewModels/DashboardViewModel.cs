using System;
using System.Collections.Generic;
using System.Windows.Media;
using System.Windows.Threading;
using ActivityTracker.Domain.Enums;
using ActivityTracker.Domain.Models;
using ActivityTracker.UI.Api;
using ActivityTracker.UI.Helpers;
using ActivityTracker.UI.Mvvm;

namespace ActivityTracker.UI.ViewModels
{
    /// <summary>Gösterge paneli: bugünün özet kartları + anlık durum (backend'den çekilir).</summary>
    public class DashboardViewModel : ViewModelBase
    {
        private readonly BackendApiClient _client;
        private readonly Func<string> _targetUser;
        private readonly DispatcherTimer _timer;

        public DashboardViewModel(BackendApiClient client, Func<string> targetUser)
        {
            _client = client;
            _targetUser = targetUser;

            _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(5) };
            _timer.Tick += async (s, e) => await RefreshAsync();
            _timer.Start();

            // İlk yükleme.
            _ = RefreshAsync();
        }

        private string _statusText = "—";
        public string StatusText { get => _statusText; set => SetProperty(ref _statusText, value); }

        private Brush _statusBrush = Brushes.Gray;
        public Brush StatusBrush { get => _statusBrush; set => SetProperty(ref _statusBrush, value); }

        private string _totalTime = "0 sn";
        public string TotalTime { get => _totalTime; set => SetProperty(ref _totalTime, value); }

        private string _activeTime = "0 sn";
        public string ActiveTime { get => _activeTime; set => SetProperty(ref _activeTime, value); }

        private string _idleTime = "0 sn";
        public string IdleTime { get => _idleTime; set => SetProperty(ref _idleTime, value); }

        private string _lockedTime = "0 sn";
        public string LockedTime { get => _lockedTime; set => SetProperty(ref _lockedTime, value); }

        private string _firstLogin = "-";
        public string FirstLogin { get => _firstLogin; set => SetProperty(ref _firstLogin, value); }

        private string _lastActivity = "-";
        public string LastActivity { get => _lastActivity; set => SetProperty(ref _lastActivity, value); }

        private string _refreshedAt = "-";
        public string RefreshedAt { get => _refreshedAt; set => SetProperty(ref _refreshedAt, value); }

        private double _activePercentage;
        public double ActivePercentage { get => _activePercentage; set => SetProperty(ref _activePercentage, value); }

        private string _todayLabel;
        public string TodayLabel { get => _todayLabel; set => SetProperty(ref _todayLabel, value); }

        /// <summary>Görüntülenen kullanıcının başlığı (yönetici başka kullanıcıya bakarken).</summary>
        private string _subjectLabel;
        public string SubjectLabel { get => _subjectLabel; set => SetProperty(ref _subjectLabel, value); }

        public void Stop() => _timer.Stop();

        public async System.Threading.Tasks.Task RefreshAsync()
        {
            var today = DateTime.Today;
            TodayLabel = today.ToString("dd MMMM yyyy");
            var target = _targetUser?.Invoke();
            SubjectLabel = target == null ? null : "Görüntülenen kullanıcı: " + target;

            try
            {
                var report = await _client.GetReportAsync(target, today);
                var events = await _client.GetEventsAsync(target, today);

                TotalTime = TimeFormat.Humanize(report.TotalTime);
                ActiveTime = TimeFormat.Humanize(report.ActiveTime);
                IdleTime = TimeFormat.Humanize(report.IdleTime);
                LockedTime = TimeFormat.Humanize(report.LockedTime);
                FirstLogin = TimeFormat.ClockOrDash(report.FirstLogin);
                LastActivity = TimeFormat.ClockOrDash(report.LastActivity);
                ActivePercentage = report.ActivePercentage;
                RefreshedAt = DateTime.Now.ToString("HH:mm:ss");

                ApplyStatus(DeriveStatus(events));
            }
            catch
            {
                StatusText = "Bağlantı yok";
                StatusBrush = Resource("DangerBrush");
                RefreshedAt = DateTime.Now.ToString("HH:mm:ss");
            }
        }

        /// <summary>Günün son olayından anlık durumu türetir.</summary>
        private static UserStatusKind DeriveStatus(IList<ActivityEvent> events)
        {
            if (events == null || events.Count == 0) return UserStatusKind.Offline;
            var last = events[events.Count - 1];

            if ((DateTime.Now - last.Timestamp) > TimeSpan.FromMinutes(10)
                && last.EventType != ActivityEventType.Lock
                && last.EventType != ActivityEventType.Sleep)
                return UserStatusKind.Offline;

            switch (last.EventType)
            {
                case ActivityEventType.IdleStart: return UserStatusKind.Idle;
                case ActivityEventType.Lock: return UserStatusKind.Locked;
                case ActivityEventType.Sleep: return UserStatusKind.Sleeping;
                case ActivityEventType.Logout:
                case ActivityEventType.ShuttingDown: return UserStatusKind.Offline;
                default: return UserStatusKind.Active;
            }
        }

        private void ApplyStatus(UserStatusKind status)
        {
            switch (status)
            {
                case UserStatusKind.Active:
                    StatusText = "Aktif"; StatusBrush = Resource("SuccessBrush"); break;
                case UserStatusKind.Idle:
                    StatusText = "Pasif (Boşta)"; StatusBrush = Resource("WarningBrush"); break;
                case UserStatusKind.Locked:
                    StatusText = "Ekran Kilitli"; StatusBrush = Resource("NavyBrush"); break;
                case UserStatusKind.Sleeping:
                    StatusText = "Uyku Modu"; StatusBrush = Resource("TextSecondaryBrush"); break;
                default:
                    StatusText = "Çevrimdışı"; StatusBrush = Resource("DangerBrush"); break;
            }
        }

        private static Brush Resource(string key)
        {
            var app = System.Windows.Application.Current;
            return app?.TryFindResource(key) as Brush ?? Brushes.Gray;
        }

        private enum UserStatusKind { Active, Idle, Locked, Sleeping, Offline }
    }
}
