namespace ActivityTracker.UI.ViewModels
{
    /// <summary>Haftalık grafikte tek bir günün çubuğu.</summary>
    public class DayBarViewModel
    {
        public string DayLabel { get; set; }      // "Pzt"
        public string DateLabel { get; set; }      // "16.06"
        public string TotalText { get; set; }      // "8 sa 30 dk"
        public double BarHeight { get; set; }      // piksel
        public bool IsToday { get; set; }
    }
}
