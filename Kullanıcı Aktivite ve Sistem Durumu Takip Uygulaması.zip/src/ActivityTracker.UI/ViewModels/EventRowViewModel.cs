using System.Windows.Media;
using ActivityTracker.Domain.Enums;
using ActivityTracker.Domain.Models;

namespace ActivityTracker.UI.ViewModels
{
    /// <summary>DataGrid'de gösterilen tek bir olay satırı.</summary>
    public class EventRowViewModel
    {
        public string Time { get; set; }
        public string TypeLabel { get; set; }
        public string Details { get; set; }
        public Brush BadgeBrush { get; set; }

        public static EventRowViewModel From(ActivityEvent ev)
        {
            return new EventRowViewModel
            {
                Time = ev.Timestamp.ToString("HH:mm:ss"),
                TypeLabel = ev.EventTypeLabel,
                Details = ev.Details ?? string.Empty,
                BadgeBrush = BrushFor(ev.EventType)
            };
        }

        private static Brush BrushFor(ActivityEventType type)
        {
            string key;
            switch (type)
            {
                case ActivityEventType.Login:
                case ActivityEventType.Unlock:
                case ActivityEventType.ActiveStart:
                case ActivityEventType.Wake:
                    key = "SuccessBrush"; break;
                case ActivityEventType.IdleStart:
                    key = "WarningBrush"; break;
                case ActivityEventType.Lock:
                case ActivityEventType.Sleep:
                    key = "PrimaryBrush"; break;
                case ActivityEventType.Logout:
                case ActivityEventType.ShuttingDown:
                    key = "DangerBrush"; break;
                default:
                    key = "TextSecondaryBrush"; break;
            }
            var app = System.Windows.Application.Current;
            return (app?.TryFindResource(key) as Brush) ?? Brushes.Gray;
        }
    }
}
