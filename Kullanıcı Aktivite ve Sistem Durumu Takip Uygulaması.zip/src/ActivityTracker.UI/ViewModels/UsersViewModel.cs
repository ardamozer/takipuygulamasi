using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using ActivityTracker.UI.Api;
using ActivityTracker.UI.Mvvm;

namespace ActivityTracker.UI.ViewModels
{
    /// <summary>Yönetici görünümü: kullanıcı listesi + hesap ekleme/silme.</summary>
    public class UsersViewModel : ViewModelBase
    {
        private readonly BackendApiClient _client;
        private readonly Action<string> _onSelect;

        public UsersViewModel(BackendApiClient client, Action<string> onSelect)
        {
            _client = client;
            _onSelect = onSelect;
            RefreshCommand = new RelayCommand(() => _ = LoadAsync());
            AddUserCommand = new RelayCommand(() => _ = AddUserAsync());
        }

        public ObservableCollection<UserRowViewModel> Users { get; } =
            new ObservableCollection<UserRowViewModel>();

        private int _count;
        public int Count { get => _count; set => SetProperty(ref _count, value); }

        private string _error;
        public string Error { get => _error; set => SetProperty(ref _error, value); }

        // ---- Yeni kullanıcı formu ----
        private string _newUsername;
        public string NewUsername { get => _newUsername; set => SetProperty(ref _newUsername, value); }

        private string _newDisplayName;
        public string NewDisplayName { get => _newDisplayName; set => SetProperty(ref _newDisplayName, value); }

        private string _newPassword;
        public string NewPassword { get => _newPassword; set => SetProperty(ref _newPassword, value); }

        private bool _newIsAdmin;
        public bool NewIsAdmin { get => _newIsAdmin; set => SetProperty(ref _newIsAdmin, value); }

        private string _formMessage;
        public string FormMessage { get => _formMessage; set => SetProperty(ref _formMessage, value); }

        public RelayCommand RefreshCommand { get; }
        public RelayCommand AddUserCommand { get; }

        public async Task LoadAsync()
        {
            try
            {
                var list = await _client.GetUsersAsync();
                Users.Clear();
                foreach (var dto in list)
                    Users.Add(UserRowViewModel.From(dto, _onSelect, ConfirmDelete, _client.Username));
                Count = Users.Count;
                Error = null;
            }
            catch
            {
                Users.Clear();
                Count = 0;
                Error = "Kullanıcılar yüklenemedi (backend bağlantısını kontrol edin).";
            }
        }

        private async Task AddUserAsync()
        {
            FormMessage = null;

            if (string.IsNullOrWhiteSpace(NewUsername) || string.IsNullOrEmpty(NewPassword))
            {
                FormMessage = "Kullanıcı adı ve parola gerekli.";
                return;
            }

            try
            {
                var err = await _client.CreateUserAsync(
                    NewUsername.Trim(), NewPassword, NewDisplayName?.Trim(), NewIsAdmin);
                if (err != null)
                {
                    FormMessage = err;
                    return;
                }

                FormMessage = "Hesap oluşturuldu: " + NewUsername.Trim();
                NewUsername = NewDisplayName = NewPassword = null;
                NewIsAdmin = false;
                await LoadAsync();
            }
            catch
            {
                FormMessage = "Hesap oluşturulamadı (backend bağlantısını kontrol edin).";
            }
        }

        private void ConfirmDelete(string username)
        {
            Error = null;
            var result = MessageBox.Show(
                "'" + username + "' hesabını silmek istediğinize emin misiniz?\n" +
                "(Toplanan loglar silinmez; yalnızca giriş hesabı kaldırılır.)",
                "Kullanıcıyı Sil", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
                _ = DeleteAsync(username);
        }

        private async Task DeleteAsync(string username)
        {
            try
            {
                var err = await _client.DeleteUserAsync(username);
                if (err != null) { Error = err; return; }
                Error = null;
                await LoadAsync();
            }
            catch
            {
                Error = "Kullanıcı silinemedi (backend bağlantısını kontrol edin).";
            }
        }
    }
}
