using System;

namespace ActivityTracker.UI.Helpers
{
    /// <summary>Süreleri kullanıcı dostu Türkçe metne çevirir.</summary>
    public static class TimeFormat
    {
        /// <summary>Örn: "3 sa 30 dk", "45 dk", "12 sn".</summary>
        public static string Humanize(TimeSpan span)
        {
            if (span < TimeSpan.Zero) span = TimeSpan.Zero;

            int hours = (int)span.TotalHours;
            int minutes = span.Minutes;
            int seconds = span.Seconds;

            if (hours > 0)
                return string.Format("{0} sa {1} dk", hours, minutes);
            if (minutes > 0)
                return string.Format("{0} dk {1} sn", minutes, seconds);
            return string.Format("{0} sn", seconds);
        }

        /// <summary>"HH:mm" biçimi (boşsa "-").</summary>
        public static string ClockOrDash(DateTime? value)
        {
            return value.HasValue ? value.Value.ToString("HH:mm") : "-";
        }
    }
}
