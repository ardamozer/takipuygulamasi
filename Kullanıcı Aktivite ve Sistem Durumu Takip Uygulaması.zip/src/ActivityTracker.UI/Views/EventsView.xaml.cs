using System.Windows.Controls;

namespace ActivityTracker.UI.Views
{
    public partial class EventsView : UserControl
    {
        public EventsView()
        {
            InitializeComponent();
        }
    }
}
