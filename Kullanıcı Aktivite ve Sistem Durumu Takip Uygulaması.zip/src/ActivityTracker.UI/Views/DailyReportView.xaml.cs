using System.Windows.Controls;

namespace ActivityTracker.UI.Views
{
    public partial class DailyReportView : UserControl
    {
        public DailyReportView()
        {
            InitializeComponent();
        }
    }
}
