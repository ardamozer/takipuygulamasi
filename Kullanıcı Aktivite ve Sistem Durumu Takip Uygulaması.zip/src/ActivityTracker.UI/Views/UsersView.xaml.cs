using System.Windows;
using System.Windows.Controls;
using ActivityTracker.UI.ViewModels;

namespace ActivityTracker.UI.Views
{
    public partial class UsersView : UserControl
    {
        public UsersView()
        {
            InitializeComponent();
        }

        // Parola güvenlik için bağlanmaz; "Ekle"de PasswordBox'tan okunup komut çalıştırılır.
        private void OnAddClick(object sender, RoutedEventArgs e)
        {
            if (DataContext is UsersViewModel vm)
            {
                vm.NewPassword = NewPasswordBox.Password;
                if (vm.AddUserCommand.CanExecute(null))
                    vm.AddUserCommand.Execute(null);
                NewPasswordBox.Clear();
            }
        }
    }
}
