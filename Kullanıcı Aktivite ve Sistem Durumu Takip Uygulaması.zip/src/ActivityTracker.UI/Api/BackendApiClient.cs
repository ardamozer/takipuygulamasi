using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using ActivityTracker.Domain.Api;
using ActivityTracker.Domain.Models;
using Newtonsoft.Json;

namespace ActivityTracker.UI.Api
{
    /// <summary>
    /// Backend Web API istemcisi. Giriş sonrası Bearer jetonunu taşır;
    /// kullanıcı (me) ve yönetici (admin) uçlarına erişir.
    /// </summary>
    public class BackendApiClient
    {
        private readonly HttpClient _http = new HttpClient { Timeout = TimeSpan.FromSeconds(10) };
        private string _baseUrl;

        public BackendApiClient(string baseUrl)
        {
            BaseUrl = baseUrl;
        }

        public string BaseUrl
        {
            get => _baseUrl;
            set => _baseUrl = (value ?? string.Empty).TrimEnd('/');
        }

        public string Username { get; private set; }
        public string DisplayName { get; private set; }
        public string Role { get; private set; }
        public bool IsAdmin => string.Equals(Role, "Admin", StringComparison.OrdinalIgnoreCase);

        /// <summary>Giriş yapar; başarılıysa jetonu saklar ve true döner.</summary>
        public async Task<bool> LoginAsync(string username, string password)
        {
            var content = Json(new LoginRequest { Username = username, Password = password });
            var resp = await _http.PostAsync(_baseUrl + "/api/auth/login", content).ConfigureAwait(false);

            // Sadece 401 "kullanıcı adı/parola hatalı" demektir.
            if (resp.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                return false;

            // Diğer başarısız durumlar (503/500/404...) parola sorunu değildir;
            // backend çalışmıyor ya da yanlış adres olabilir -> anlamlı hata ver.
            if (!resp.IsSuccessStatusCode)
                throw new InvalidOperationException(
                    "Backend beklenmeyen yanıt verdi (HTTP " + (int)resp.StatusCode +
                    "). Backend çalışmıyor olabilir veya adres yanlış.");

            var body = await resp.Content.ReadAsStringAsync().ConfigureAwait(false);
            var login = JsonConvert.DeserializeObject<LoginResponse>(body);
            if (login == null || string.IsNullOrEmpty(login.Token)) return false;

            Username = login.Username;
            DisplayName = login.DisplayName;
            Role = login.Role;
            _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", login.Token);
            return true;
        }

        // ---- Veri uçları. targetUser == null ise giriş yapan kullanıcının kendi verisi. ----

        public Task<DailyReport> GetReportAsync(string targetUser, DateTime date)
        {
            var path = targetUser == null
                ? $"/api/me/report?date={D(date)}"
                : $"/api/admin/users/{Uri.EscapeDataString(targetUser)}/report?date={D(date)}";
            return GetAsync<DailyReport>(path);
        }

        public Task<List<ActivityEvent>> GetEventsAsync(string targetUser, DateTime date)
        {
            var path = targetUser == null
                ? $"/api/me/events?date={D(date)}"
                : $"/api/admin/users/{Uri.EscapeDataString(targetUser)}/events?date={D(date)}";
            return GetAsync<List<ActivityEvent>>(path);
        }

        public Task<List<DailyReport>> GetWeekAsync(string targetUser, DateTime weekStart)
        {
            var path = targetUser == null
                ? $"/api/me/week?date={D(weekStart)}"
                : $"/api/admin/users/{Uri.EscapeDataString(targetUser)}/week?date={D(weekStart)}";
            return GetAsync<List<DailyReport>>(path);
        }

        public Task<List<UserSummaryDto>> GetUsersAsync()
        {
            return GetAsync<List<UserSummaryDto>>("/api/admin/users");
        }

        /// <summary>Yeni hesap oluşturur. Başarısızsa sunucunun hata metnini döndürür.</summary>
        public async Task<string> CreateUserAsync(string username, string password, string displayName, bool isAdmin)
        {
            var req = new CreateUserRequest
            {
                Username = username,
                Password = password,
                DisplayName = displayName,
                Role = isAdmin ? "Admin" : "User"
            };
            var resp = await _http.PostAsync(_baseUrl + "/api/admin/users", Json(req)).ConfigureAwait(false);
            if (resp.IsSuccessStatusCode) return null;
            return await ErrorText(resp).ConfigureAwait(false);
        }

        /// <summary>Hesabı siler. Başarısızsa sunucunun hata metnini döndürür.</summary>
        public async Task<string> DeleteUserAsync(string username)
        {
            var resp = await _http.DeleteAsync(_baseUrl + "/api/admin/users/" + Uri.EscapeDataString(username)).ConfigureAwait(false);
            if (resp.IsSuccessStatusCode) return null;
            return await ErrorText(resp).ConfigureAwait(false);
        }

        private static async Task<string> ErrorText(System.Net.Http.HttpResponseMessage resp)
        {
            try
            {
                var body = await resp.Content.ReadAsStringAsync().ConfigureAwait(false);
                // Web API hata gövdesi { "Message": "..." } biçimindedir.
                var obj = JsonConvert.DeserializeObject<ErrorBody>(body);
                if (!string.IsNullOrWhiteSpace(obj?.Message)) return obj.Message;
                return string.IsNullOrWhiteSpace(body) ? ("HTTP " + (int)resp.StatusCode) : body;
            }
            catch
            {
                return "HTTP " + (int)resp.StatusCode;
            }
        }

        private class ErrorBody { public string Message { get; set; } }

        private async Task<T> GetAsync<T>(string path)
        {
            var resp = await _http.GetAsync(_baseUrl + path).ConfigureAwait(false);
            resp.EnsureSuccessStatusCode();
            var body = await resp.Content.ReadAsStringAsync().ConfigureAwait(false);
            return JsonConvert.DeserializeObject<T>(body);
        }

        private static string D(DateTime date) => date.ToString("yyyy-MM-dd");

        private static StringContent Json(object o) =>
            new StringContent(JsonConvert.SerializeObject(o), Encoding.UTF8, "application/json");
    }
}
