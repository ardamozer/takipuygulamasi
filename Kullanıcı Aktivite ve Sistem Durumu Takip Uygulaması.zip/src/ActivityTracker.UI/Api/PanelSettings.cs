using System;
using System.IO;

namespace ActivityTracker.UI.Api
{
    /// <summary>
    /// Panel (WPF istemci) ayarları. %AppData%\HetabilPanel\panel.ini içinde
    /// backend adresini saklar.
    /// </summary>
    public class PanelSettings
    {
        public string BackendUrl { get; set; } = "http://localhost:5005";

        private static string Dir =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "HetabilPanel");

        private static string FilePath => Path.Combine(Dir, "panel.ini");

        public static PanelSettings Load()
        {
            var s = new PanelSettings();
            try
            {
                if (File.Exists(FilePath))
                {
                    foreach (var raw in File.ReadAllLines(FilePath))
                    {
                        var line = raw.Trim();
                        var idx = line.IndexOf('=');
                        if (idx <= 0) continue;
                        var key = line.Substring(0, idx).Trim().ToLowerInvariant();
                        var val = line.Substring(idx + 1).Trim();
                        if (key == "backendurl") s.BackendUrl = val;
                    }
                }
            }
            catch { /* varsayılanlarla devam */ }
            return s;
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Dir);
                File.WriteAllText(FilePath, "BackendUrl=" + BackendUrl + "\r\n");
            }
            catch { /* yazılamazsa sessiz geç */ }
        }
    }
}
