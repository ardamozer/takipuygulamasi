using System.Windows;
using ActivityTracker.UI.Api;
using ActivityTracker.UI.ViewModels;

namespace ActivityTracker.UI
{
    /// <summary>
    /// Panel uygulaması yaşam döngüsü: önce giriş ekranı, başarılı girişte rol bazlı
    /// ana pencere. Veri toplama/arka plan işi artık ayrı Agent uygulamasındadır;
    /// bu uygulama yalnızca backend'e bağlanan bir görüntüleme panelidir.
    /// </summary>
    public partial class App : Application
    {
        private PanelSettings _settings;
        private MainWindow _main;
        private bool _loggingOut;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            _settings = PanelSettings.Load();
            ShowLogin();
        }

        private void ShowLogin()
        {
            var login = new LoginWindow(_settings);
            var ok = login.ShowDialog();
            if (ok == true && login.Client != null)
                OpenMain(login.Client);
            else
                Shutdown();
        }

        private void OpenMain(BackendApiClient client)
        {
            var vm = new MainViewModel(client, _settings);
            vm.LogoutRequested += OnLogoutRequested;

            _main = new MainWindow { DataContext = vm };
            _main.Closed += OnMainClosed;
            _main.Show();
        }

        private void OnLogoutRequested()
        {
            _loggingOut = true;
            _main.Close();
        }

        private void OnMainClosed(object sender, System.EventArgs e)
        {
            _main = null;
            if (_loggingOut)
            {
                _loggingOut = false;
                ShowLogin();   // tekrar giriş ekranı
            }
            else
            {
                Shutdown();    // pencere kapatıldı → uygulamadan çık
            }
        }
    }
}
