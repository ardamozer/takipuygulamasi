using System.Drawing;
using System.Windows.Forms;

namespace ActivityTracker.Launcher
{
    /// <summary>Ilk derleme sirasinda gosterilen kucuk, kenarliksiz bilgi penceresi.</summary>
    internal sealed class HazirlikPenceresi : Form
    {
        public HazirlikPenceresi()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(360, 90);
            BackColor = Color.FromArgb(32, 32, 32);
            ShowInTaskbar = false;
            TopMost = true;

            Controls.Add(new Label
            {
                Dock = DockStyle.Fill,
                Text = "Hetabil hazirlaniyor, lutfen bekleyin...",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11F),
                TextAlign = ContentAlignment.MiddleCenter
            });
        }
    }
}
