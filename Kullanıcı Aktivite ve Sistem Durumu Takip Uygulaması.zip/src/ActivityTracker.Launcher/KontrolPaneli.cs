using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace ActivityTracker.Launcher
{
    /// <summary>
    /// Hetabil kontrol paneli: tek pencereden backend/agent/panel baslatma-durdurma
    /// ve otomatik baslatma kurma-kaldirma. Her dugme ayni launcher exe'sini ilgili
    /// argumanla yeniden calistirir; tum is mantigi ve UAC yukseltme orada kalir,
    /// burada kopya yoktur. Backend/Agent durumu canli gosterilir.
    /// </summary>
    internal sealed class KontrolPaneli : Form
    {
        // Durum tespiti icin surec adlari (exe adi, uzantisiz).
        private const string BackendProc = "ActivityTracker.Backend";
        private const string AgentProc = "HetabilActivityAgent";

        private static readonly Color Bg = Color.FromArgb(32, 32, 32);
        private static readonly Color Notr = Color.FromArgb(60, 60, 60);
        private static readonly Color Fg = Color.White;
        private static readonly Color Accent = Color.FromArgb(0, 120, 215);
        private static readonly Color Durdur = Color.FromArgb(170, 60, 60);

        private readonly Label _backendDurum;
        private readonly Label _agentDurum;
        private readonly Button _backendBaslat;
        private readonly Button _backendDurdur;
        private readonly Timer _yenile;

        public KontrolPaneli()
        {
            Text = "Hetabil Baslatici";
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Bg;
            ClientSize = new Size(380, 402);
            Padding = new Padding(14);
            TrySetIcon();

            var grid = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                BackColor = Bg
            };
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));

            var baslik = new Label
            {
                Text = "Hetabil Baslatici",
                ForeColor = Fg,
                Font = new Font("Segoe UI Semibold", 13F),
                AutoSize = false,
                Dock = DockStyle.Fill,
                Height = 34,
                TextAlign = ContentAlignment.MiddleLeft
            };

            _backendDurum = DurumLabel();
            _agentDurum = DurumLabel();

            _backendBaslat = Buton("Backend Baslat", Accent, () => Calistir("backend"));
            _backendDurdur = Buton("Backend Durdur", Durdur, () => Calistir("durdur"));
            var agentBaslat = Buton("Agent Baslat", Accent, () => Calistir("agent"));
            var panelAc = Buton("Panel Ac", Accent, () => Calistir("panel"));
            var hepsini = Buton("Hepsini Baslat", Accent, () => Calistir("all"));
            var otoBaslik = new Label
            {
                Text = "Windows acilista otomatik baslat:",
                ForeColor = Color.Gainsboro,
                Font = new Font("Segoe UI", 9F),
                AutoSize = false,
                Dock = DockStyle.Fill,
                Height = 22,
                TextAlign = ContentAlignment.MiddleLeft,
                Margin = new Padding(4, 6, 4, 0)
            };
            var otoKur = Buton("Kur", Notr, () => Calistir("sched-install"));
            var otoKaldir = Buton("Kaldir", Notr, () => Calistir("sched-remove"));

            AddSpan(grid, baslik, 0);
            AddSpan(grid, _backendDurum, 1);
            AddSpan(grid, _agentDurum, 2);
            grid.Controls.Add(_backendBaslat, 0, 3);
            grid.Controls.Add(_backendDurdur, 1, 3);
            AddSpan(grid, agentBaslat, 4);
            AddSpan(grid, panelAc, 5);
            AddSpan(grid, hepsini, 6);
            AddSpan(grid, otoBaslik, 7);
            grid.Controls.Add(otoKur, 0, 8);
            grid.Controls.Add(otoKaldir, 1, 8);

            Controls.Add(grid);

            _yenile = new Timer { Interval = 1500 };
            _yenile.Tick += (s, e) => DurumGuncelle();
            _yenile.Start();
            DurumGuncelle();
        }

        private static void AddSpan(TableLayoutPanel grid, Control c, int row)
        {
            grid.Controls.Add(c, 0, row);
            grid.SetColumnSpan(c, 2);
        }

        private static Label DurumLabel() => new Label
        {
            ForeColor = Fg,
            Font = new Font("Segoe UI", 10F),
            AutoSize = false,
            Dock = DockStyle.Fill,
            Height = 24,
            TextAlign = ContentAlignment.MiddleLeft
        };

        private static Button Buton(string metin, Color renk, Action eylem)
        {
            var b = new Button
            {
                Text = metin,
                Dock = DockStyle.Fill,
                Height = 38,
                FlatStyle = FlatStyle.Flat,
                ForeColor = Fg,
                BackColor = renk,
                Font = new Font("Segoe UI", 9.5F),
                Margin = new Padding(4),
                Cursor = Cursors.Hand
            };
            b.FlatAppearance.BorderSize = 0;
            b.Click += (s, e) => eylem();
            return b;
        }

        /// <summary>Ayni launcher exe'sini verilen argumanla yeniden baslatir.</summary>
        private void Calistir(string arg)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = Application.ExecutablePath,
                    Arguments = arg,
                    UseShellExecute = true,
                    WorkingDirectory = Path.GetDirectoryName(Application.ExecutablePath)
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Hetabil - Hata",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DurumGuncelle()
        {
            bool backend = Calisiyor(BackendProc);
            bool agent = Calisiyor(AgentProc);

            _backendDurum.Text = "Backend:  " + (backend ? "● calisiyor" : "○ kapali");
            _backendDurum.ForeColor = backend ? Color.LightGreen : Color.IndianRed;
            _agentDurum.Text = "Agent:    " + (agent ? "● calisiyor" : "○ kapali");
            _agentDurum.ForeColor = agent ? Color.LightGreen : Color.IndianRed;

            // Backend acikken "Baslat"i, kapaliyken "Durdur"u devre disi birak.
            _backendBaslat.Enabled = !backend;
            _backendDurdur.Enabled = backend;
        }

        private static bool Calisiyor(string procAd)
        {
            try { return Process.GetProcessesByName(procAd).Length > 0; }
            catch { return false; }
        }

        private void TrySetIcon()
        {
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); }
            catch { /* yut */ }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _yenile?.Dispose();
            base.Dispose(disposing);
        }
    }
}
