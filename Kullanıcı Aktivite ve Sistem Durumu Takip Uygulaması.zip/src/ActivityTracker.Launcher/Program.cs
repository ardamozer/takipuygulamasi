using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Security.Principal;
using System.Threading;
using System.Windows.Forms;

namespace ActivityTracker.Launcher
{
    /// <summary>
    /// Bat dosyalarinin yerini alan tek launcher. Derlenen exe, repo kokune
    /// Agent-Baslat / Panel-Baslat / Backend-Baslat / Hepsini-Baslat / Backend-Durdur
    /// adlariyla kopyalanir; her kopya kendi adindan ne yapacagini secer.
    ///
    /// Backend-Baslat  = backend'i aga acar (firewall+urlacl) ve baslatir.
    /// Backend-Durdur  = backend'i durdurur ve aga erisimi kapatir.
    /// Ag islemleri yonetici gerektirir; exe gerektiginde kendini yukseltir (UAC).
    /// </summary>
    internal static class Program
    {
        private const string Sln = "HetabilActivityTracker.sln";

        private const int Port = 5005;
        private const string AgentKey = "hetabil-agent-key";
        private const string FwRule = "Hetabil Backend";

        private const string BackendBin = @"src\ActivityTracker.Backend\bin\Debug\net46";
        private const string BackendExe = BackendBin + @"\ActivityTracker.Backend.exe";
        private const string AgentExe = @"src\ActivityTracker.Agent.Host\bin\Debug\net46\HetabilActivityAgent.exe";
        private const string PanelExe = @"src\ActivityTracker.UI\bin\Debug\net46\HetabilActivityTracker.exe";

        private static string _root;
        private static bool _quiet;   // /quiet -> popup/pencere gosterme (otomatik baslatma icin)

        [STAThread]
        private static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            _root = RepoKokunuBul();
            _quiet = args != null && args.Any(a =>
                a.Equals("/quiet", StringComparison.OrdinalIgnoreCase) ||
                a.Equals("quiet", StringComparison.OrdinalIgnoreCase));

            try
            {
                // Yonetici olarak yeniden baslatilan dahili adimlar:
                if (args != null && args.Length > 0)
                {
                    string a0 = args[0].ToLowerInvariant();
                    if (a0 == "netopen") { AgiAc(); return; }
                    if (a0 == "netclose") { AgiKapat(); return; }
                    if (a0 == "schedinstall") { SchedKur(); return; }
                    if (a0 == "schedremove") { SchedKaldir(); return; }
                }

                switch (IslemiBelirle(args))
                {
                    case "agent": Baslat(AgentExe, "Agent"); break;
                    case "panel": Baslat(PanelExe, "Panel"); break;
                    case "backend": BackendBaslatVeAgiAc(); break;
                    case "durdur": BackendDurdurVeAgiKapat(); break;
                    case "all": HepsiniBaslat(); break;
                    case "sched-install": OtomatikBaslatKur(); break;
                    case "sched-remove": OtomatikBaslatKaldir(); break;
                    case "kontrol": Application.Run(new KontrolPaneli()); break;
                    default:
                        MessageBox.Show(
                            "Ne yapilacagi anlasilamadi. Exe adi Agent / Panel / Backend / Hepsini / Durdur / Otomatik icermeli.",
                            "Hetabil", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Hetabil - Hata",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>Calisan exe'nin adina (yoksa ilk argumana) gore islemi secer.</summary>
        private static string IslemiBelirle(string[] args)
        {
            string ad = Path.GetFileNameWithoutExtension(Application.ExecutablePath).ToLowerInvariant();
            if (ad.Contains("otomatik"))                  // "Otomatik-Baslat-Kur/Kaldir"
                return ad.Contains("kaldir") ? "sched-remove" : "sched-install";
            if (ad.Contains("durdur")) return "durdur";   // "Backend-Durdur" -> once durdur
            if (ad.Contains("backend")) return "backend";
            if (ad.Contains("agent")) return "agent";
            if (ad.Contains("panel")) return "panel";
            if (ad.Contains("hepsini") || ad.Contains("all")) return "all";
            if (args != null && args.Length > 0) return args[0].ToLowerInvariant();
            return "kontrol";   // arguman yoksa (cift tik) kontrol panelini ac
        }

        /// <summary>Exe konumundan yukari dogru .sln iceren klasoru arar.</summary>
        private static string RepoKokunuBul()
        {
            var dir = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
            while (dir != null)
            {
                if (File.Exists(Path.Combine(dir.FullName, Sln)))
                    return dir.FullName;
                dir = dir.Parent;
            }
            return AppDomain.CurrentDomain.BaseDirectory;
        }

        // ---- Basit baslaticilar (agent / panel) -------------------------------

        private static void Baslat(string relExe, string baslik)
        {
            string tam = Path.Combine(_root, relExe);
            if (!File.Exists(tam)) Derle();
            if (!File.Exists(tam))
                throw new FileNotFoundException(baslik + " calistirilabilir dosyasi bulunamadi:\n" + tam);
            ExeBaslat(tam);
        }

        private static void HepsiniBaslat()
        {
            string backend = Path.Combine(_root, BackendExe);
            string agent = Path.Combine(_root, AgentExe);
            string panel = Path.Combine(_root, PanelExe);

            if (!File.Exists(backend) || !File.Exists(agent) || !File.Exists(panel))
                Derle();

            ExeBaslat(backend);   // 1/3 Backend
            Thread.Sleep(4000);   // backend hazirlansin
            ExeBaslat(agent);     // 2/3 Agent (sistem tepsisi)
            ExeBaslat(panel);     // 3/3 Panel
        }

        // ---- Backend baslat + aga ac ------------------------------------------

        private static void BackendBaslatVeAgiAc()
        {
            string backend = Path.Combine(_root, BackendExe);
            if (!File.Exists(backend)) Derle();
            if (!File.Exists(backend))
                throw new FileNotFoundException("Backend bulunamadi:\n" + backend);

            bool acildi;
            if (YukseltilmisMi())
            {
                AgiAc();
                acildi = true;
            }
            else if (_quiet)
            {
                acildi = false;                     // otomatik baslatmada UAC sorma, yerelde basla
            }
            else
            {
                acildi = KendiniYukselt("netopen"); // UAC kabul edilirse true
            }

            ExeBaslat(backend);

            if (_quiet) return;                     // sessiz mod: popup yok

            if (acildi)
                MessageBox.Show(
                    "Backend baslatildi ve aga acildi.\n\nDiger PC'lere verilecek IP adresi:\n" + YerelIpler(),
                    "Hetabil - Backend", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show(
                    "Backend yerelde baslatildi.\n(Yonetici izni verilmedigi icin aga acilamadi.)",
                    "Hetabil - Backend", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        /// <summary>[Yonetici] backend.ini yazar, urlacl + guvenlik duvari kuralini ekler.</summary>
        private static void AgiAc()
        {
            string bin = Path.Combine(_root, BackendBin);
            Directory.CreateDirectory(bin);
            File.WriteAllText(Path.Combine(bin, "backend.ini"),
                "# Hetabil Backend yapilandirmasi\r\n" +
                "Url=http://+:" + Port + "\r\n" +
                "AgentApiKey=" + AgentKey + "\r\n");

            string user = WindowsIdentity.GetCurrent().Name;

            // Backend'in (yonetici olmadan) http://+:PORT dinleyebilmesi icin rezervasyon
            RunHidden("netsh", "http add urlacl url=http://+:" + Port + "/ user=\"" + user + "\"");

            // Guvenlik duvari: once eskiyi sil, sonra ekle
            RunHidden("netsh", "advfirewall firewall delete rule name=\"" + FwRule + "\"");
            RunHidden("netsh", "advfirewall firewall add rule name=\"" + FwRule +
                "\" dir=in action=allow protocol=TCP localport=" + Port);
        }

        // ---- Backend durdur + agi kapat ---------------------------------------

        private static void BackendDurdurVeAgiKapat()
        {
            if (YukseltilmisMi())
            {
                AgiKapat();
            }
            else if (!KendiniYukselt("netclose"))
            {
                // UAC reddedildi: en azindan process'i durdur (kendi kullanicimiz, admin gerekmez)
                RunHidden("taskkill", "/F /IM ActivityTracker.Backend.exe");
                MessageBox.Show(
                    "Backend durduruldu.\n(Yonetici izni verilmedigi icin guvenlik duvari/urlacl kurallari kaldirilamadi.)",
                    "Hetabil - Backend", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show("Backend durduruldu ve aga erisim kapatildi.",
                "Hetabil - Backend", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>[Yonetici] backend'i durdurur, guvenlik duvari kuralini ve urlacl'i kaldirir.</summary>
        private static void AgiKapat()
        {
            RunHidden("taskkill", "/F /IM ActivityTracker.Backend.exe");
            RunHidden("netsh", "advfirewall firewall delete rule name=\"" + FwRule + "\"");
            RunHidden("netsh", "http delete urlacl url=http://+:" + Port + "/");
        }

        // ---- Otomatik baslatma (Task Scheduler) -------------------------------

        private static void OtomatikBaslatKur()
        {
            if (YukseltilmisMi())
                SchedKur();
            else if (!KendiniYukselt("schedinstall"))
                MessageBox.Show("Yonetici izni verilmedi; otomatik baslatma kurulamadi.",
                    "Hetabil", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private static void OtomatikBaslatKaldir()
        {
            if (YukseltilmisMi())
                SchedKaldir();
            else if (!KendiniYukselt("schedremove"))
                MessageBox.Show("Yonetici izni verilmedi; otomatik baslatma kaldirilamadi.",
                    "Hetabil", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        /// <summary>[Yonetici] Backend ve Agent icin oturum-acilis gorevlerini olusturur.</summary>
        private static void SchedKur()
        {
            // Tek launcher; islem argumanla secilir (ayri Backend-/Agent-Baslat.exe kopyalari kaldirildi).
            string launcher = Path.Combine(_root, "HetabilBaslat.exe");

            // Backend: oturum acilista, en yuksek ayricaliklarla (UAC sormadan aga acar), sessiz
            int b = RunHidden("schtasks",
                "/Create /TN \"" + StartupTask.BackendName + "\" /TR \"\\\"" + launcher + "\\\" backend /quiet\" /SC ONLOGON /RL HIGHEST /F");
            // Agent: oturum acilista, normal ayricalik
            int a = RunHidden("schtasks",
                "/Create /TN \"" + StartupTask.AgentName + "\" /TR \"\\\"" + launcher + "\\\" agent\" /SC ONLOGON /F");

            if (b == 0 && a == 0)
                MessageBox.Show(
                    "Otomatik baslatma kuruldu.\n\nWindows'a her giriste:\n" +
                    "  - Backend baslar ve aga acilir (sessiz, UAC sormaz)\n" +
                    "  - Agent baslar\n\n" +
                    "Kaldirmak icin: Otomatik-Baslat-Kaldir.exe",
                    "Hetabil - Otomatik Baslatma", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show(
                    "Gorevler olusturulurken sorun olustu.\n(schtasks cikis kodu: Backend=" + b + ", Agent=" + a + ")",
                    "Hetabil - Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        /// <summary>[Yonetici] Backend ve Agent oturum-acilis gorevlerini siler.</summary>
        private static void SchedKaldir()
        {
            RunHidden("schtasks", "/Delete /TN \"" + StartupTask.BackendName + "\" /F");
            RunHidden("schtasks", "/Delete /TN \"" + StartupTask.AgentName + "\" /F");
            MessageBox.Show(
                "Otomatik baslatma kaldirildi.\n(Backend ve Agent artik oturum acilista otomatik baslamaz.)",
                "Hetabil - Otomatik Baslatma", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // ---- Yardimcilar -------------------------------------------------------

        private static bool YukseltilmisMi()
        {
            using (var id = WindowsIdentity.GetCurrent())
                return new WindowsPrincipal(id).IsInRole(WindowsBuiltInRole.Administrator);
        }

        /// <summary>Kendini yonetici olarak verilen argumanla calistirir ve bitmesini bekler.</summary>
        private static bool KendiniYukselt(string arg)
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = Application.ExecutablePath,
                    Arguments = arg,
                    WorkingDirectory = _root,
                    UseShellExecute = true,
                    Verb = "runas"
                };
                using (var p = Process.Start(psi))
                    p.WaitForExit();
                return true;
            }
            catch
            {
                return false; // UAC iptal edildi
            }
        }

        private static void ExeBaslat(string tamYol)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = tamYol,
                WorkingDirectory = Path.GetDirectoryName(tamYol),
                UseShellExecute = true
            });
        }

        /// <summary>Ilk calistirmada solution'i sessizce derler (pencere yok).</summary>
        private static void Derle()
        {
            using (var splash = new HazirlikPenceresi())
            {
                splash.Show();
                Application.DoEvents();

                int kod = RunHidden("dotnet", "build \"" + Path.Combine(_root, Sln) + "\" -v quiet");
                if (kod != 0)
                    throw new Exception("Derleme basarisiz oldu.\n.NET SDK kurulu mu? (dotnet build)");
            }
        }

        /// <summary>Bir konsol programini pencere acmadan calistirir, cikis kodunu doner.</summary>
        private static int RunHidden(string dosya, string args)
        {
            var psi = new ProcessStartInfo
            {
                FileName = dosya,
                Arguments = args,
                WorkingDirectory = _root,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };

            using (var p = new Process { StartInfo = psi })
            {
                p.OutputDataReceived += (s, e) => { };
                p.ErrorDataReceived += (s, e) => { };
                p.Start();
                p.BeginOutputReadLine();
                p.BeginErrorReadLine();
                p.WaitForExit();
                return p.ExitCode;
            }
        }

        /// <summary>Bu makinenin yerel IPv4 adres(ler)ini metin olarak doner.</summary>
        private static string YerelIpler()
        {
            try
            {
                var list = Dns.GetHostAddresses(Dns.GetHostName())
                    .Where(a => a.AddressFamily == AddressFamily.InterNetwork)
                    .Select(a => a.ToString())
                    .Where(s => !s.StartsWith("127.") && !s.StartsWith("169.254."))
                    .ToArray();
                return list.Length > 0 ? string.Join("\r\n", list) : "(IP bulunamadi - ipconfig ile bakin)";
            }
            catch
            {
                return "(IP okunamadi)";
            }
        }
    }
}
