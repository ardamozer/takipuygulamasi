using System;
using System.Threading;
using System.Windows.Forms;

namespace ActivityTracker.Agent.Host
{
    internal static class Program
    {
        private static Mutex _mutex;

        [STAThread]
        private static void Main()
        {
            // Tek örnek çalışsın.
            _mutex = new Mutex(true, "HetabilActivityAgent_SingleInstance", out var createdNew);
            if (!createdNew) return;

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new AgentTrayContext());

            GC.KeepAlive(_mutex);
        }
    }
}
