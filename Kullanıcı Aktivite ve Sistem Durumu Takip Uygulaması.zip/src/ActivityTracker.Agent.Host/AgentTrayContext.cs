using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace ActivityTracker.Agent.Host
{
    /// <summary>
    /// Agent'ı arka planda çalıştıran uygulama bağlamı. WinForms mesaj döngüsü
    /// sağlar (SystemEvents tabanlı izleyiciler için şart), tepsi simgesi gösterir
    /// ve AgentEngine'i başlatır.
    /// </summary>
    public class AgentTrayContext : ApplicationContext
    {
        private readonly NotifyIcon _trayIcon;
        private readonly AgentEngine _engine;
        private readonly ToolStripMenuItem _startupItem;

        public AgentTrayContext()
        {
            var settings = AgentSettings.Load();
            _engine = new AgentEngine(settings);

            // Agent başlar başlamaz otomatik başlatmayı garanti et: görev yoksa kur.
            bool startupOn = AgentStartupManager.IsEnabled();
            if (!startupOn)
                startupOn = AgentStartupManager.SetEnabled(true);

            // "Windows ile başlat" varsayılan olarak aktif gelir. Yalnızca yönetici
            // değiştirebilir; normal kullanıcılarda devre dışı (gri) görünür, böylece
            // kapatamazlar. Devre dışı öğede tooltip görünmediğinden, yönetici
            // gerektiği bilgisini metne koyuyoruz.
            bool elevated = AgentStartupManager.IsElevated();
            _startupItem = new ToolStripMenuItem(
                elevated ? "Windows ile başlat" : "Windows ile başlat (yönetici gerekir)",
                null, ToggleStartup)
            {
                Checked = startupOn,
                CheckOnClick = elevated,
                Enabled = elevated
            };

            var menu = new ContextMenuStrip();
            menu.Items.AddRange(new ToolStripItem[]
            {
                new ToolStripMenuItem("Hetabil Aktivite Agent") { Enabled = false },
                new ToolStripSeparator(),
                _startupItem,
                new ToolStripMenuItem("Çıkış", null, (s, e) => ExitAgent())
            });

            _trayIcon = new NotifyIcon
            {
                Icon = LoadIcon(),
                Visible = true,
                Text = "Hetabil Aktivite Agent",
                ContextMenuStrip = menu
            };

            _engine.Start();
        }

        private void ToggleStartup(object sender, EventArgs e)
        {
            // Menü öğesi yalnızca yöneticide etkin olduğu için buraya sadece
            // yönetici gelir. CheckOnClick zaten Checked'i çevirdi; yeni duruma
            // göre görevi kur/kaldır, ardından gerçek durumla eşitle.
            AgentStartupManager.SetEnabled(_startupItem.Checked);
            _startupItem.Checked = AgentStartupManager.IsEnabled();
        }

        private void ExitAgent()
        {
            try { _engine.Dispose(); } catch { /* yut */ }
            _trayIcon.Visible = false;
            _trayIcon.Dispose();
            ExitThread();
        }

        private static Icon LoadIcon()
        {
            try
            {
                return Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location)
                       ?? SystemIcons.Application;
            }
            catch
            {
                return SystemIcons.Application;
            }
        }
    }
}
