using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Security.Principal;

namespace ActivityTracker.Agent.Host
{
    /// <summary>
    /// Agent'ın Windows oturum açılışında otomatik başlamasını Görev Zamanlayıcı
    /// (Task Scheduler) üzerinden yönetir. Görev adı Launcher ile ortaktır
    /// (<see cref="StartupTask.AgentName"/>).
    ///
    /// Yönetici olarak çalışırken görev en yüksek ayrıcalıkla (/RL HIGHEST)
    /// oluşturulur; böylece normal kullanıcılar görevi silip otomatik başlatmayı
    /// kapatamaz. (Eski HKCU\...\Run kayıt defteri yöntemi kaldırıldı.)
    /// </summary>
    public static class AgentStartupManager
    {
        // schtasks.exe'yi tam yoldan çağır (PATH'e bağımlı olma / PATH hijack'i önle).
        private static readonly string SchtasksPath =
            Path.Combine(Environment.SystemDirectory, "schtasks.exe");

        private const string DQ = "\"";      // çift tırnak
        private const string EDQ = "\\\"";   // komut satırında kaçışlı çift tırnak: \"

        /// <summary>Oturum-açılış görevi tanımlı mı?</summary>
        public static bool IsEnabled()
        {
            try
            {
                return RunSchtasks("/Query /TN " + Arg(StartupTask.AgentName)) == 0;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>Süreç yönetici (administrator) ayrıcalığıyla mı çalışıyor?</summary>
        public static bool IsElevated()
        {
            try
            {
                using (var id = WindowsIdentity.GetCurrent())
                    return new WindowsPrincipal(id).IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>Görevi kurar (true) veya kaldırır (false).</summary>
        /// <returns>schtasks işlemi başarılı olduysa true.</returns>
        public static bool SetEnabled(bool enabled)
        {
            try
            {
                if (enabled)
                {
                    string exe = Assembly.GetExecutingAssembly().Location;
                    // Yönetici isek görevi kilitle: HIGHEST görevini kaldırmak/değiştirmek
                    // yönetici ister, böylece normal kullanıcı kapatamaz.
                    string level = IsElevated() ? " /RL HIGHEST" : string.Empty;
                    return RunSchtasks(
                        "/Create /TN " + Arg(StartupTask.AgentName) +
                        " /TR " + RunArg(exe) +
                        " /SC ONLOGON" + level + " /F") == 0;
                }

                return RunSchtasks("/Delete /TN " + Arg(StartupTask.AgentName) + " /F") == 0;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>Bir parametre değerini tek argüman olacak şekilde tırnaklar: "değer".</summary>
        private static string Arg(string value) => DQ + value + DQ;

        /// <summary>
        /// /TR için hedef komut: schtasks tek argüman bekler, ayrıca boşluklu yolu
        /// koruması için yolu kendi tırnakları içinde ister -> "\"&lt;exe&gt;\"".
        /// </summary>
        private static string RunArg(string exe) => DQ + EDQ + exe + EDQ + DQ;

        /// <summary>schtasks.exe'yi pencere açmadan çalıştırır, çıkış kodunu döner.</summary>
        private static int RunSchtasks(string args)
        {
            var psi = new ProcessStartInfo
            {
                FileName = SchtasksPath,
                Arguments = args,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };

            using (var p = new Process { StartInfo = psi })
            {
                // Çıktıyı asenkron boşalt (tampon dolup kilitlenmeyi önler).
                p.OutputDataReceived += (s, e) => { };
                p.ErrorDataReceived += (s, e) => { };
                p.Start();
                p.BeginOutputReadLine();
                p.BeginErrorReadLine();
                p.WaitForExit();
                return p.ExitCode;
            }
        }
    }
}
