using System;
using System.IO;

namespace ActivityTracker.Data
{
    /// <summary>
    /// Veritabanı konumu ve bağlantı dizesi yapılandırması.
    /// Varsayılan olarak %AppData%\HetabilActivityTracker\activity.db kullanılır.
    /// </summary>
    public static class DatabaseConfig
    {
        private static string _databasePath;

        /// <summary>SQLite veritabanı dosyasının tam yolu.</summary>
        public static string DatabasePath
        {
            get
            {
                if (string.IsNullOrEmpty(_databasePath))
                {
                    var folder = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                        "HetabilActivityTracker");
                    Directory.CreateDirectory(folder);
                    _databasePath = Path.Combine(folder, "activity.db");
                }
                return _databasePath;
            }
            set { _databasePath = value; }
        }

        /// <summary>SQLite bağlantı dizesi.</summary>
        public static string ConnectionString
        {
            get { return string.Format("Data Source={0};Version=3;", DatabasePath); }
        }

        /// <summary>Tarih/saat değerlerinin veritabanında saklandığı biçim.</summary>
        public const string DateTimeFormat = "yyyy-MM-dd HH:mm:ss.fff";
    }
}
