using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Globalization;
using ActivityTracker.Domain.Enums;
using ActivityTracker.Domain.Models;

namespace ActivityTracker.Data.Repositories
{
    /// <summary>SQLite tabanlı panel hesabı deposu.</summary>
    public class UserRepository : IUserRepository
    {
        public User GetByUsername(string username)
        {
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText =
                        "SELECT Id, Username, DisplayName, PasswordHash, PasswordSalt, Role, CreatedAt " +
                        "FROM Users WHERE Username = @user COLLATE NOCASE LIMIT 1;";
                    command.Parameters.AddWithValue("@user", username);
                    using (var reader = command.ExecuteReader())
                    {
                        return reader.Read() ? Map(reader) : null;
                    }
                }
            }
        }

        public long Add(User user)
        {
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText =
                        "INSERT INTO Users (Username, DisplayName, PasswordHash, PasswordSalt, Role, CreatedAt) " +
                        "VALUES (@user, @name, @hash, @salt, @role, @created); SELECT last_insert_rowid();";
                    command.Parameters.AddWithValue("@user", user.Username);
                    command.Parameters.AddWithValue("@name", (object)user.DisplayName ?? DBNull.Value);
                    command.Parameters.AddWithValue("@hash", user.PasswordHash);
                    command.Parameters.AddWithValue("@salt", user.PasswordSalt);
                    command.Parameters.AddWithValue("@role", (int)user.Role);
                    command.Parameters.AddWithValue("@created", FormatDate(user.CreatedAt == default(DateTime) ? DateTime.Now : user.CreatedAt));
                    var id = (long)command.ExecuteScalar();
                    user.Id = id;
                    return id;
                }
            }
        }

        public IList<User> ListAll()
        {
            var result = new List<User>();
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText =
                        "SELECT Id, Username, DisplayName, PasswordHash, PasswordSalt, Role, CreatedAt " +
                        "FROM Users ORDER BY Username ASC;";
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                            result.Add(Map(reader));
                    }
                }
            }
            return result;
        }

        public void SetRole(string username, UserRole role)
        {
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText =
                        "UPDATE Users SET Role = @role WHERE Username = @user COLLATE NOCASE;";
                    command.Parameters.AddWithValue("@role", (int)role);
                    command.Parameters.AddWithValue("@user", username);
                    command.ExecuteNonQuery();
                }
            }
        }

        public void SetPassword(string username, string passwordHash, string passwordSalt)
        {
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText =
                        "UPDATE Users SET PasswordHash = @hash, PasswordSalt = @salt " +
                        "WHERE Username = @user COLLATE NOCASE;";
                    command.Parameters.AddWithValue("@hash", passwordHash);
                    command.Parameters.AddWithValue("@salt", passwordSalt);
                    command.Parameters.AddWithValue("@user", username);
                    command.ExecuteNonQuery();
                }
            }
        }

        public int Delete(string username)
        {
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "DELETE FROM Users WHERE Username = @user COLLATE NOCASE;";
                    command.Parameters.AddWithValue("@user", username);
                    return command.ExecuteNonQuery();
                }
            }
        }

        public int CountByRole(UserRole role)
        {
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT COUNT(1) FROM Users WHERE Role = @role;";
                    command.Parameters.AddWithValue("@role", (int)role);
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        public bool Any()
        {
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT COUNT(1) FROM Users;";
                    var count = Convert.ToInt64(command.ExecuteScalar());
                    return count > 0;
                }
            }
        }

        private static User Map(SQLiteDataReader reader)
        {
            return new User
            {
                Id = reader.GetInt64(0),
                Username = reader.GetString(1),
                DisplayName = reader.IsDBNull(2) ? null : reader.GetString(2),
                PasswordHash = reader.GetString(3),
                PasswordSalt = reader.GetString(4),
                Role = (UserRole)reader.GetInt32(5),
                CreatedAt = ParseDate(reader.GetString(6))
            };
        }

        private static string FormatDate(DateTime value)
        {
            return value.ToString(DatabaseConfig.DateTimeFormat, CultureInfo.InvariantCulture);
        }

        private static DateTime ParseDate(string value)
        {
            return DateTime.ParseExact(value, DatabaseConfig.DateTimeFormat, CultureInfo.InvariantCulture);
        }
    }
}
