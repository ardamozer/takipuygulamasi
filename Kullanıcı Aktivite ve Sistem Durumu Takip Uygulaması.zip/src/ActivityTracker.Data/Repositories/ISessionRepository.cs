using System;
using System.Collections.Generic;
using ActivityTracker.Domain.Models;

namespace ActivityTracker.Data.Repositories
{
    /// <summary>Kullanıcı oturumları için veri erişim arayüzü.</summary>
    public interface ISessionRepository
    {
        /// <summary>Yeni oturum başlatır, atanan Id'yi döner.</summary>
        long StartSession(string userName, DateTime loginTime, string machine = null);

        /// <summary>Açık oturumu kapatır (çıkış zamanını yazar).</summary>
        void EndSession(long sessionId, DateTime logoutTime);

        /// <summary>Kapatılmamış (açık kalmış) en son oturumu döner; yoksa null.</summary>
        UserSession GetOpenSession(string userName);

        /// <summary>Belirtilen güne ait oturumları döner.</summary>
        IList<UserSession> GetByDate(string userName, DateTime date);
    }
}
