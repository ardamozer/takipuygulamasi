using System.Collections.Generic;
using ActivityTracker.Domain.Models;

namespace ActivityTracker.Data.Repositories
{
    /// <summary>Panel giriş hesapları için veri erişim arayüzü.</summary>
    public interface IUserRepository
    {
        /// <summary>Kullanıcı adına göre hesabı döner; yoksa null.</summary>
        User GetByUsername(string username);

        /// <summary>Yeni hesap ekler, atanan Id'yi döner.</summary>
        long Add(User user);

        /// <summary>Tüm hesapları döner.</summary>
        IList<User> ListAll();

        /// <summary>Bir hesabın rolünü günceller.</summary>
        void SetRole(string username, Domain.Enums.UserRole role);

        /// <summary>Bir hesabın parola özetini ve tuzunu günceller.</summary>
        void SetPassword(string username, string passwordHash, string passwordSalt);

        /// <summary>Bir giriş hesabını siler. Silinen satır sayısını döner.</summary>
        int Delete(string username);

        /// <summary>Belirtilen roldeki hesap sayısını döner (son admin korumasında kullanılır).</summary>
        int CountByRole(Domain.Enums.UserRole role);

        /// <summary>Hiç hesap var mı? (ilk açılışta admin tohumlamak için).</summary>
        bool Any();
    }
}
