using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Globalization;
using ActivityTracker.Domain.Enums;
using ActivityTracker.Domain.Models;

namespace ActivityTracker.Data.Repositories
{
    /// <summary>SQLite tabanlı aktivite olayı deposu.</summary>
    public class EventRepository : IEventRepository
    {
        public long Add(ActivityEvent activityEvent)
        {
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText =
                        "INSERT INTO ActivityEvents (UserName, EventType, Timestamp, Details, Machine) " +
                        "VALUES (@user, @type, @ts, @details, @machine); SELECT last_insert_rowid();";
                    command.Parameters.AddWithValue("@user", activityEvent.UserName);
                    command.Parameters.AddWithValue("@type", (int)activityEvent.EventType);
                    command.Parameters.AddWithValue("@ts", FormatDate(activityEvent.Timestamp));
                    command.Parameters.AddWithValue("@details", (object)activityEvent.Details ?? DBNull.Value);
                    command.Parameters.AddWithValue("@machine", (object)activityEvent.Machine ?? DBNull.Value);

                    var id = (long)command.ExecuteScalar();
                    activityEvent.Id = id;
                    return id;
                }
            }
        }

        public IList<ActivityEvent> GetByDate(string userName, DateTime date)
        {
            var start = date.Date;
            var end = start.AddDays(1);
            return GetBetween(userName, start, end);
        }

        public IList<ActivityEvent> GetBetween(string userName, DateTime start, DateTime end)
        {
            var result = new List<ActivityEvent>();
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText =
                        "SELECT Id, UserName, EventType, Timestamp, Details, Machine FROM ActivityEvents " +
                        "WHERE UserName = @user AND Timestamp >= @start AND Timestamp < @end " +
                        "ORDER BY Timestamp ASC, Id ASC;";
                    command.Parameters.AddWithValue("@user", userName);
                    command.Parameters.AddWithValue("@start", FormatDate(start));
                    command.Parameters.AddWithValue("@end", FormatDate(end));

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(Map(reader));
                        }
                    }
                }
            }
            return result;
        }

        public DateTime? GetLastActivity(string userName)
        {
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText =
                        "SELECT MAX(Timestamp) FROM ActivityEvents " +
                        "WHERE UserName = @user AND EventType IN (@active, @login, @unlock);";
                    command.Parameters.AddWithValue("@user", userName);
                    command.Parameters.AddWithValue("@active", (int)ActivityEventType.ActiveStart);
                    command.Parameters.AddWithValue("@login", (int)ActivityEventType.Login);
                    command.Parameters.AddWithValue("@unlock", (int)ActivityEventType.Unlock);

                    var value = command.ExecuteScalar();
                    if (value == null || value == DBNull.Value)
                        return null;
                    return ParseDate((string)value);
                }
            }
        }

        public IList<ActivityEvent> GetByDateAllUsers(DateTime date)
        {
            var start = date.Date;
            var end = start.AddDays(1);
            var result = new List<ActivityEvent>();
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText =
                        "SELECT Id, UserName, EventType, Timestamp, Details, Machine FROM ActivityEvents " +
                        "WHERE Timestamp >= @start AND Timestamp < @end " +
                        "ORDER BY Timestamp ASC, Id ASC;";
                    command.Parameters.AddWithValue("@start", FormatDate(start));
                    command.Parameters.AddWithValue("@end", FormatDate(end));
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                            result.Add(Map(reader));
                    }
                }
            }
            return result;
        }

        public IList<string> GetDistinctUsers()
        {
            var result = new List<string>();
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText =
                        "SELECT DISTINCT UserName FROM ActivityEvents ORDER BY UserName ASC;";
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                            result.Add(reader.GetString(0));
                    }
                }
            }
            return result;
        }

        public ActivityEvent GetLastEvent(string userName)
        {
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText =
                        "SELECT Id, UserName, EventType, Timestamp, Details, Machine FROM ActivityEvents " +
                        "WHERE UserName = @user ORDER BY Timestamp DESC, Id DESC LIMIT 1;";
                    command.Parameters.AddWithValue("@user", userName);
                    using (var reader = command.ExecuteReader())
                    {
                        return reader.Read() ? Map(reader) : null;
                    }
                }
            }
        }

        private static ActivityEvent Map(SQLiteDataReader reader)
        {
            return new ActivityEvent
            {
                Id = reader.GetInt64(0),
                UserName = reader.GetString(1),
                EventType = (ActivityEventType)reader.GetInt32(2),
                Timestamp = ParseDate(reader.GetString(3)),
                Details = reader.IsDBNull(4) ? null : reader.GetString(4),
                Machine = reader.IsDBNull(5) ? null : reader.GetString(5)
            };
        }

        private static string FormatDate(DateTime value)
        {
            return value.ToString(DatabaseConfig.DateTimeFormat, CultureInfo.InvariantCulture);
        }

        private static DateTime ParseDate(string value)
        {
            return DateTime.ParseExact(value, DatabaseConfig.DateTimeFormat, CultureInfo.InvariantCulture);
        }
    }
}
