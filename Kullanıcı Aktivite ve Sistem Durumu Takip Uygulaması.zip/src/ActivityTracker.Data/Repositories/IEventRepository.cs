using System;
using System.Collections.Generic;
using ActivityTracker.Domain.Models;

namespace ActivityTracker.Data.Repositories
{
    /// <summary>Aktivite olayları için veri erişim arayüzü.</summary>
    public interface IEventRepository
    {
        /// <summary>Yeni bir olay kaydeder ve atanan Id'yi döner.</summary>
        long Add(ActivityEvent activityEvent);

        /// <summary>Belirtilen güne ait olayları zamana göre sıralı döner.</summary>
        IList<ActivityEvent> GetByDate(string userName, DateTime date);

        /// <summary>Belirtilen zaman aralığındaki olayları döner.</summary>
        IList<ActivityEvent> GetBetween(string userName, DateTime start, DateTime end);

        /// <summary>Kullanıcının en son aktivite (ActiveStart) zamanını döner; yoksa null.</summary>
        DateTime? GetLastActivity(string userName);

        // ---- Yönetici sorguları (tüm kullanıcılar) ----

        /// <summary>Belirtilen güne ait TÜM kullanıcıların olaylarını döner.</summary>
        IList<ActivityEvent> GetByDateAllUsers(DateTime date);

        /// <summary>Olay kaydı bulunan farklı kullanıcı adlarını döner.</summary>
        IList<string> GetDistinctUsers();

        /// <summary>Kullanıcının en son olayını döner (durum/makine türetmek için); yoksa null.</summary>
        ActivityEvent GetLastEvent(string userName);
    }
}
