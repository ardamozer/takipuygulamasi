using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Globalization;
using ActivityTracker.Domain.Models;

namespace ActivityTracker.Data.Repositories
{
    /// <summary>SQLite tabanlı kullanıcı oturumu deposu.</summary>
    public class SessionRepository : ISessionRepository
    {
        public long StartSession(string userName, DateTime loginTime, string machine = null)
        {
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText =
                        "INSERT INTO UserSessions (UserName, LoginTime, Machine) VALUES (@user, @login, @machine); " +
                        "SELECT last_insert_rowid();";
                    command.Parameters.AddWithValue("@user", userName);
                    command.Parameters.AddWithValue("@login", FormatDate(loginTime));
                    command.Parameters.AddWithValue("@machine", (object)machine ?? DBNull.Value);
                    return (long)command.ExecuteScalar();
                }
            }
        }

        public void EndSession(long sessionId, DateTime logoutTime)
        {
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText =
                        "UPDATE UserSessions SET LogoutTime = @logout " +
                        "WHERE Id = @id AND LogoutTime IS NULL;";
                    command.Parameters.AddWithValue("@logout", FormatDate(logoutTime));
                    command.Parameters.AddWithValue("@id", sessionId);
                    command.ExecuteNonQuery();
                }
            }
        }

        public UserSession GetOpenSession(string userName)
        {
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText =
                        "SELECT Id, UserName, LoginTime, LogoutTime, Machine FROM UserSessions " +
                        "WHERE UserName = @user AND LogoutTime IS NULL " +
                        "ORDER BY LoginTime DESC LIMIT 1;";
                    command.Parameters.AddWithValue("@user", userName);
                    using (var reader = command.ExecuteReader())
                    {
                        return reader.Read() ? Map(reader) : null;
                    }
                }
            }
        }

        public IList<UserSession> GetByDate(string userName, DateTime date)
        {
            var start = date.Date;
            var end = start.AddDays(1);
            var result = new List<UserSession>();
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText =
                        "SELECT Id, UserName, LoginTime, LogoutTime, Machine FROM UserSessions " +
                        "WHERE UserName = @user AND LoginTime >= @start AND LoginTime < @end " +
                        "ORDER BY LoginTime ASC;";
                    command.Parameters.AddWithValue("@user", userName);
                    command.Parameters.AddWithValue("@start", FormatDate(start));
                    command.Parameters.AddWithValue("@end", FormatDate(end));
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                            result.Add(Map(reader));
                    }
                }
            }
            return result;
        }

        private static UserSession Map(SQLiteDataReader reader)
        {
            return new UserSession
            {
                Id = reader.GetInt64(0),
                UserName = reader.GetString(1),
                LoginTime = ParseDate(reader.GetString(2)),
                LogoutTime = reader.IsDBNull(3) ? (DateTime?)null : ParseDate(reader.GetString(3)),
                Machine = reader.IsDBNull(4) ? null : reader.GetString(4)
            };
        }

        private static string FormatDate(DateTime value)
        {
            return value.ToString(DatabaseConfig.DateTimeFormat, CultureInfo.InvariantCulture);
        }

        private static DateTime ParseDate(string value)
        {
            return DateTime.ParseExact(value, DatabaseConfig.DateTimeFormat, CultureInfo.InvariantCulture);
        }
    }
}
