using System;
using System.Security.Cryptography;

namespace ActivityTracker.Data.Security
{
    /// <summary>
    /// PBKDF2 (Rfc2898 / HMAC-SHA1) ile parola özetleme ve doğrulama.
    /// Kullanıcı başına rastgele tuz üretir.
    /// </summary>
    public static class PasswordHasher
    {
        private const int SaltSize = 16;     // 128 bit
        private const int HashSize = 32;      // 256 bit
        private const int Iterations = 100000;

        /// <summary>Yeni bir tuz + özet üretir (Base64).</summary>
        public static void CreateHash(string password, out string hashBase64, out string saltBase64)
        {
            var salt = new byte[SaltSize];
            using (var rng = new RNGCryptoServiceProvider())
                rng.GetBytes(salt);

            var hash = Derive(password, salt);
            hashBase64 = Convert.ToBase64String(hash);
            saltBase64 = Convert.ToBase64String(salt);
        }

        /// <summary>Verilen parola, saklanan tuz+özetle eşleşiyor mu?</summary>
        public static bool Verify(string password, string hashBase64, string saltBase64)
        {
            if (string.IsNullOrEmpty(hashBase64) || string.IsNullOrEmpty(saltBase64))
                return false;

            byte[] salt, expected;
            try
            {
                salt = Convert.FromBase64String(saltBase64);
                expected = Convert.FromBase64String(hashBase64);
            }
            catch (FormatException)
            {
                return false;
            }

            var actual = Derive(password, salt);
            return FixedTimeEquals(actual, expected);
        }

        private static byte[] Derive(string password, byte[] salt)
        {
            using (var pbkdf2 = new Rfc2898DeriveBytes(password ?? string.Empty, salt, Iterations))
                return pbkdf2.GetBytes(HashSize);
        }

        /// <summary>Zamanlama saldırılarına karşı sabit süreli karşılaştırma.</summary>
        private static bool FixedTimeEquals(byte[] a, byte[] b)
        {
            if (a.Length != b.Length) return false;
            var diff = 0;
            for (var i = 0; i < a.Length; i++)
                diff |= a[i] ^ b[i];
            return diff == 0;
        }
    }
}
