using System;
using System.Data.SQLite;
using ActivityTracker.Data.Repositories;
using ActivityTracker.Data.Security;
using ActivityTracker.Domain.Enums;
using ActivityTracker.Domain.Models;

namespace ActivityTracker.Data
{
    /// <summary>
    /// Veritabanı dosyasını ve tabloları (yoksa) oluşturur ve ilk açılışta
    /// varsayılan yönetici hesabını tohumlar. Backend açılışta bir kez çağırır.
    /// </summary>
    public static class DatabaseInitializer
    {
        /// <summary>İlk açılışta oluşturulan varsayılan yönetici hesabı.</summary>
        public const string DefaultAdminUsername = "admin";
        public const string DefaultAdminPassword = "admin123";

        public static void Initialize()
        {
            // Dosya yoksa System.Data.SQLite bağlantı açılınca oluşturur.
            using (var connection = new SQLiteConnection(DatabaseConfig.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = CreateTablesSql;
                    command.ExecuteNonQuery();
                }
            }

            SeedDefaultAdmin();
        }

        private static void SeedDefaultAdmin()
        {
            var users = new UserRepository();
            if (users.Any()) return;

            PasswordHasher.CreateHash(DefaultAdminPassword, out var hash, out var salt);
            users.Add(new User
            {
                Username = DefaultAdminUsername,
                DisplayName = "Yönetici",
                PasswordHash = hash,
                PasswordSalt = salt,
                Role = UserRole.Admin,
                CreatedAt = DateTime.Now
            });
        }

        private const string CreateTablesSql = @"
CREATE TABLE IF NOT EXISTS ActivityEvents (
    Id         INTEGER PRIMARY KEY AUTOINCREMENT,
    UserName   TEXT    NOT NULL,
    EventType  INTEGER NOT NULL,
    Timestamp  TEXT    NOT NULL,
    Details    TEXT,
    Machine    TEXT
);

CREATE INDEX IF NOT EXISTS IX_ActivityEvents_Timestamp ON ActivityEvents (Timestamp);
CREATE INDEX IF NOT EXISTS IX_ActivityEvents_User      ON ActivityEvents (UserName);

CREATE TABLE IF NOT EXISTS UserSessions (
    Id         INTEGER PRIMARY KEY AUTOINCREMENT,
    UserName   TEXT    NOT NULL,
    LoginTime  TEXT    NOT NULL,
    LogoutTime TEXT,
    Machine    TEXT
);

CREATE INDEX IF NOT EXISTS IX_UserSessions_Login ON UserSessions (LoginTime);

CREATE TABLE IF NOT EXISTS Users (
    Id           INTEGER PRIMARY KEY AUTOINCREMENT,
    Username     TEXT    NOT NULL UNIQUE,
    DisplayName  TEXT,
    PasswordHash TEXT    NOT NULL,
    PasswordSalt TEXT    NOT NULL,
    Role         INTEGER NOT NULL DEFAULT 0,
    CreatedAt    TEXT    NOT NULL
);

CREATE INDEX IF NOT EXISTS IX_Users_Username ON Users (Username);

CREATE TABLE IF NOT EXISTS AppUsage (
    Id           INTEGER PRIMARY KEY AUTOINCREMENT,
    UserName     TEXT    NOT NULL,
    ProcessName  TEXT    NOT NULL,
    WindowTitle  TEXT,
    Date         TEXT    NOT NULL,
    TotalSeconds INTEGER NOT NULL DEFAULT 0
);
";
    }
}
