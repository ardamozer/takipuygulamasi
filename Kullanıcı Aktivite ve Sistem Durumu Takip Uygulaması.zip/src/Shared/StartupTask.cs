namespace ActivityTracker
{
    /// <summary>
    /// Oturum-açılış (Task Scheduler) görevlerinin ortak adları. Hem Agent.Host
    /// (tepsi menüsündeki "Windows ile başlat") hem Launcher (Otomatik-Baslat-Kur)
    /// bu sabitleri kullanır; aynı ad iki projede ayrı ayrı yazılmaz.
    ///
    /// Bu dosya her iki projeye de &lt;Compile Link&gt; ile bağlanır (ayrı assembly
    /// referansı yoktur), bu yüzden tip internal kalabilir.
    /// </summary>
    internal static class StartupTask
    {
        /// <summary>Agent'ı oturum açılışında başlatan görevin adı.</summary>
        public const string AgentName = "Hetabil Agent";

        /// <summary>Backend'i oturum açılışında başlatan görevin adı.</summary>
        public const string BackendName = "Hetabil Backend";
    }
}
