using System;
using ActivityTracker.Domain.Api;
using ActivityTracker.Domain.Enums;
using ActivityTracker.Services.Monitoring;

namespace ActivityTracker.Agent
{
    /// <summary>
    /// Agent'ın çekirdeği: oturum/güç/boşta izleyicilerini yönetir ve ürettikleri
    /// olayları backend'e gönderir. Eski TrackingService'in akışını izler ama
    /// veritabanı yerine HTTP kullanır.
    /// </summary>
    public class AgentEngine : IDisposable
    {
        private readonly BackendClient _client;
        private readonly SessionMonitor _sessionMonitor;
        private readonly PowerMonitor _powerMonitor;
        private readonly IdleMonitor _idleMonitor;

        private readonly string _userName;
        private readonly string _machine;
        private long _currentSessionId = -1;
        private bool _running;

        public AgentEngine(AgentSettings settings)
        {
            _client = new BackendClient(settings);
            _userName = Environment.UserName;
            _machine = Environment.MachineName;

            _sessionMonitor = new SessionMonitor();
            _powerMonitor = new PowerMonitor();
            _idleMonitor = new IdleMonitor(settings.IdleThresholdSeconds);

            _sessionMonitor.EventOccurred += OnMonitorEvent;
            _powerMonitor.EventOccurred += OnMonitorEvent;
            _idleMonitor.EventOccurred += OnMonitorEvent;
        }

        public string UserName => _userName;

        /// <summary>İzlemeyi başlatır: giriş olayı + oturum başlangıcı.</summary>
        public void Start()
        {
            if (_running) return;

            var now = DateTime.Now;
            _currentSessionId = _client.TryStartSession(new SessionStartDto
            {
                UserName = _userName,
                Machine = _machine,
                LoginTime = now
            });

            Send(ActivityEventType.Login, now, "Agent başlatıldı");

            _sessionMonitor.Start();
            _powerMonitor.Start();
            _idleMonitor.Start();
            _running = true;
        }

        /// <summary>İzlemeyi durdurur: çıkış olayı + oturum kapanışı.</summary>
        public void Stop()
        {
            if (!_running) return;

            _sessionMonitor.Stop();
            _powerMonitor.Stop();
            _idleMonitor.Stop();

            var now = DateTime.Now;
            Send(ActivityEventType.Logout, now, "Agent durduruldu");
            _client.Flush();

            if (_currentSessionId > 0)
                _client.TryEndSession(new SessionEndDto { SessionId = _currentSessionId, LogoutTime = now });

            _running = false;
        }

        private void OnMonitorEvent(object sender, ActivityEventArgs e)
        {
            Send(e.EventType, e.Timestamp, e.Details);
        }

        private void Send(ActivityEventType type, DateTime timestamp, string details)
        {
            _client.EnqueueEvent(new EventDto
            {
                UserName = _userName,
                Machine = _machine,
                EventType = type,
                Timestamp = timestamp,
                Details = details
            });
        }

        public void Dispose()
        {
            try { Stop(); } catch { /* kapanışta hata yutulur */ }
            _client?.Dispose();
        }
    }
}
