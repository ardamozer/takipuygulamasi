using System;
using System.IO;

namespace ActivityTracker.Agent
{
    /// <summary>
    /// Agent yapılandırması. %AppData%\HetabilAgent\agent.ini dosyasından okunur;
    /// yoksa varsayılanlarla oluşturulur.
    /// </summary>
    public class AgentSettings
    {
        public string BackendUrl { get; set; } = "http://localhost:5005";
        public string AgentApiKey { get; set; } = "hetabil-agent-key";
        public int IdleThresholdSeconds { get; set; } = 60;

        public static string ConfigDirectory =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "HetabilAgent");

        private static string ConfigPath => Path.Combine(ConfigDirectory, "agent.ini");

        public static AgentSettings Load()
        {
            var settings = new AgentSettings();
            Directory.CreateDirectory(ConfigDirectory);

            if (!File.Exists(ConfigPath))
            {
                settings.Save();
                return settings;
            }

            foreach (var raw in File.ReadAllLines(ConfigPath))
            {
                var line = raw.Trim();
                if (line.Length == 0 || line.StartsWith("#") || line.StartsWith(";")) continue;
                var idx = line.IndexOf('=');
                if (idx <= 0) continue;
                var key = line.Substring(0, idx).Trim().ToLowerInvariant();
                var val = line.Substring(idx + 1).Trim();
                switch (key)
                {
                    case "backendurl": settings.BackendUrl = val; break;
                    case "agentapikey": settings.AgentApiKey = val; break;
                    case "idlethresholdseconds":
                        if (int.TryParse(val, out var s)) settings.IdleThresholdSeconds = s;
                        break;
                }
            }
            return settings;
        }

        public void Save()
        {
            Directory.CreateDirectory(ConfigDirectory);
            var content =
                "# Hetabil Aktivite Takip - Agent yapılandırması\r\n" +
                "BackendUrl=" + BackendUrl + "\r\n" +
                "AgentApiKey=" + AgentApiKey + "\r\n" +
                "IdleThresholdSeconds=" + IdleThresholdSeconds + "\r\n";
            File.WriteAllText(ConfigPath, content);
        }
    }
}
