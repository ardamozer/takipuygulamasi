using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Timers;
using ActivityTracker.Domain.Api;
using Newtonsoft.Json;

namespace ActivityTracker.Agent
{
    /// <summary>
    /// Backend ile HTTP iletişimini yönetir. Olaylar dosya destekli bir kuyruğa
    /// yazılır; backend ulaşılamazsa kuyrukta tutulur ve zamanlayıcıyla yeniden
    /// gönderilir (offline dayanıklılık). Oturum çağrıları best-effort'tur.
    /// </summary>
    public class BackendClient : IDisposable
    {
        private readonly AgentSettings _settings;
        private readonly HttpClient _http;
        private readonly string _queueFile;
        private readonly object _lock = new object();
        private readonly List<EventDto> _queue = new List<EventDto>();
        private readonly Timer _flushTimer;

        public BackendClient(AgentSettings settings)
        {
            _settings = settings;
            _http = new HttpClient { Timeout = TimeSpan.FromSeconds(10) };
            _http.DefaultRequestHeaders.Add("X-Agent-Key", settings.AgentApiKey);

            _queueFile = Path.Combine(AgentSettings.ConfigDirectory, "queue.jsonl");
            LoadQueue();

            _flushTimer = new Timer(15000) { AutoReset = true };
            _flushTimer.Elapsed += (s, e) => Flush();
            _flushTimer.Start();
        }

        private string Base => _settings.BackendUrl.TrimEnd('/');

        /// <summary>Olayı kuyruğa ekler ve hemen göndermeyi dener.</summary>
        public void EnqueueEvent(EventDto dto)
        {
            lock (_lock)
            {
                _queue.Add(dto);
                PersistQueue();
            }
            Flush();
        }

        /// <summary>Kuyruktaki tüm olayları toplu göndermeyi dener; başarısızsa korur.</summary>
        public void Flush()
        {
            List<EventDto> snapshot;
            lock (_lock)
            {
                if (_queue.Count == 0) return;
                snapshot = new List<EventDto>(_queue);
            }

            try
            {
                var batch = new EventBatchDto { Events = snapshot };
                var resp = _http.PostAsync(Base + "/api/ingest/events", Json(batch))
                    .GetAwaiter().GetResult();
                if (!resp.IsSuccessStatusCode) return; // sonra tekrar denenir

                lock (_lock)
                {
                    _queue.RemoveRange(0, snapshot.Count);
                    PersistQueue();
                }
            }
            catch
            {
                // Backend ulaşılamadı; kuyrukta kalsın, sonraki turda denenir.
            }
        }

        /// <summary>Oturum başlatır; backend ulaşılamazsa -1 döner (kritik değil).</summary>
        public long TryStartSession(SessionStartDto dto)
        {
            try
            {
                var resp = _http.PostAsync(Base + "/api/ingest/session/start", Json(dto))
                    .GetAwaiter().GetResult();
                if (!resp.IsSuccessStatusCode) return -1;
                var body = resp.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                var parsed = JsonConvert.DeserializeObject<SessionStartResponse>(body);
                return parsed?.SessionId ?? -1;
            }
            catch
            {
                return -1;
            }
        }

        /// <summary>Oturumu kapatır; başarısızlık yutulur (best-effort).</summary>
        public void TryEndSession(SessionEndDto dto)
        {
            try
            {
                _http.PostAsync(Base + "/api/ingest/session/end", Json(dto))
                    .GetAwaiter().GetResult();
            }
            catch
            {
                // best-effort
            }
        }

        private static StringContent Json(object o)
        {
            return new StringContent(JsonConvert.SerializeObject(o), Encoding.UTF8, "application/json");
        }

        private void LoadQueue()
        {
            try
            {
                if (!File.Exists(_queueFile)) return;
                foreach (var line in File.ReadAllLines(_queueFile))
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    var dto = JsonConvert.DeserializeObject<EventDto>(line);
                    if (dto != null) _queue.Add(dto);
                }
            }
            catch
            {
                // Bozuk kuyruk dosyası akışı durdurmasın.
            }
        }

        private void PersistQueue()
        {
            try
            {
                var sb = new StringBuilder();
                foreach (var dto in _queue)
                    sb.AppendLine(JsonConvert.SerializeObject(dto));
                File.WriteAllText(_queueFile, sb.ToString());
            }
            catch
            {
                // Disk hatası izlemeyi düşürmesin.
            }
        }

        public void Dispose()
        {
            _flushTimer?.Stop();
            _flushTimer?.Dispose();
            _http?.Dispose();
        }
    }
}
