namespace ActivityTracker.Domain.Enums
{
    /// <summary>
    /// Panel erişim rolleri. Kullanıcı yalnızca kendi verisini, yönetici tüm
    /// kullanıcıların verisini görebilir.
    /// </summary>
    public enum UserRole
    {
        /// <summary>Yalnızca kendi loglarını görür.</summary>
        User = 0,

        /// <summary>Tüm kullanıcıların loglarını görür.</summary>
        Admin = 1
    }
}
