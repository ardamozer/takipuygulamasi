namespace ActivityTracker.Domain.Enums
{
    /// <summary>
    /// Takip edilen sistem ve kullanıcı olaylarının türleri.
    /// </summary>
    public enum ActivityEventType
    {
        /// <summary>Kullanıcı oturumu başlattı (uygulama açıldı / giriş yapıldı).</summary>
        Login = 0,

        /// <summary>Kullanıcı oturumu kapattı (çıkış / uygulama kapandı).</summary>
        Logout = 1,

        /// <summary>Ekran kilitlendi.</summary>
        Lock = 2,

        /// <summary>Ekran kilidi açıldı.</summary>
        Unlock = 3,

        /// <summary>Bilgisayar uyku/bekleme moduna geçti.</summary>
        Sleep = 4,

        /// <summary>Bilgisayar uykudan uyandı.</summary>
        Wake = 5,

        /// <summary>Bilgisayar kapanıyor / yeniden başlatılıyor / oturum sonlanıyor.</summary>
        ShuttingDown = 6,

        /// <summary>Kullanıcı (klavye/mouse) yeniden aktif oldu.</summary>
        ActiveStart = 7,

        /// <summary>Kullanıcı hareketsiz kaldı (pasif/boşta).</summary>
        IdleStart = 8
    }
}
