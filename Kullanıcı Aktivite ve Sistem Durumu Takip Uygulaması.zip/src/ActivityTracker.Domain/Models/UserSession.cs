using System;

namespace ActivityTracker.Domain.Models
{
    /// <summary>
    /// Bir kullanıcı oturumu: giriş zamanından çıkış zamanına kadar.
    /// </summary>
    public class UserSession
    {
        public long Id { get; set; }

        public string UserName { get; set; }

        /// <summary>Oturumun ait olduğu makine adı (agent gönderir); eski kayıtlarda null olabilir.</summary>
        public string Machine { get; set; }

        public DateTime LoginTime { get; set; }

        /// <summary>Oturum hâlâ açıksa null.</summary>
        public DateTime? LogoutTime { get; set; }

        /// <summary>Oturum süresi. Açıksa şu ana kadar geçen süre.</summary>
        public TimeSpan Duration
        {
            get
            {
                var end = LogoutTime ?? DateTime.Now;
                var span = end - LoginTime;
                return span < TimeSpan.Zero ? TimeSpan.Zero : span;
            }
        }

        public bool IsActive
        {
            get { return LogoutTime == null; }
        }
    }
}
