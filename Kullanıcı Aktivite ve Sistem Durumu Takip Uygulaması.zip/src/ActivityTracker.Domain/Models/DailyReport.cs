using System;

namespace ActivityTracker.Domain.Models
{
    /// <summary>
    /// Bir günün özet raporu: toplam / aktif / pasif / kilitli süreler.
    /// </summary>
    public class DailyReport
    {
        public DateTime Date { get; set; }

        public string UserName { get; set; }

        /// <summary>İlk giriş - son aktivite arası geçen toplam süre (oturumda kalınan süre).</summary>
        public TimeSpan TotalTime { get; set; }

        /// <summary>Klavye/mouse ile aktif geçirilen süre.</summary>
        public TimeSpan ActiveTime { get; set; }

        /// <summary>Bilgisayar açıkken hareketsiz (boşta) geçen süre.</summary>
        public TimeSpan IdleTime { get; set; }

        /// <summary>Ekranın kilitli kaldığı süre.</summary>
        public TimeSpan LockedTime { get; set; }

        /// <summary>Bilgisayarın uyku/kapalı olduğu süre (bilinen aralıklarda).</summary>
        public TimeSpan SleepTime { get; set; }

        public DateTime? FirstLogin { get; set; }

        public DateTime? LastActivity { get; set; }

        public DailyReport()
        {
            TotalTime = TimeSpan.Zero;
            ActiveTime = TimeSpan.Zero;
            IdleTime = TimeSpan.Zero;
            LockedTime = TimeSpan.Zero;
            SleepTime = TimeSpan.Zero;
        }

        /// <summary>Aktif sürenin toplam içindeki yüzdesi (0-100).</summary>
        public double ActivePercentage
        {
            get
            {
                var total = TotalTime.TotalSeconds;
                return total <= 0 ? 0 : Math.Round(ActiveTime.TotalSeconds / total * 100.0, 1);
            }
        }
    }
}
