using System;

namespace ActivityTracker.Domain.Models
{
    /// <summary>
    /// (Opsiyonel) Açık/odakta olan bir uygulamanın kullanım süresi kaydı.
    /// </summary>
    public class AppUsage
    {
        public long Id { get; set; }

        public string UserName { get; set; }

        /// <summary>Süreç/uygulama adı (örn. "chrome", "devenv").</summary>
        public string ProcessName { get; set; }

        /// <summary>Pencere başlığı (varsa).</summary>
        public string WindowTitle { get; set; }

        public DateTime Date { get; set; }

        /// <summary>Bu uygulamanın o gün odakta kaldığı toplam süre (saniye).</summary>
        public long TotalSeconds { get; set; }

        public TimeSpan Duration
        {
            get { return TimeSpan.FromSeconds(TotalSeconds); }
        }
    }
}
