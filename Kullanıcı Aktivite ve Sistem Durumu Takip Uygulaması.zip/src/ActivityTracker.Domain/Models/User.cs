using System;
using ActivityTracker.Domain.Enums;

namespace ActivityTracker.Domain.Models
{
    /// <summary>
    /// Panel giriş hesabı. Kimlik doğrulama ve rol için kullanılır.
    /// Olaylar/oturumlar ayrıca Windows kullanıcı adıyla (UserName) saklanır;
    /// normal kullanıcının hesabı, Windows kullanıcı adıyla eşleşir.
    /// </summary>
    public class User
    {
        public long Id { get; set; }

        /// <summary>Giriş adı (normal kullanıcıda Windows kullanıcı adı).</summary>
        public string Username { get; set; }

        /// <summary>Panelde gösterilecek ad.</summary>
        public string DisplayName { get; set; }

        /// <summary>PBKDF2 parola özeti (Base64).</summary>
        public string PasswordHash { get; set; }

        /// <summary>Parola tuzu (Base64).</summary>
        public string PasswordSalt { get; set; }

        public UserRole Role { get; set; }

        public DateTime CreatedAt { get; set; }
    }
}
