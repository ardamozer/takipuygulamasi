using System;
using ActivityTracker.Domain.Enums;

namespace ActivityTracker.Domain.Models
{
    /// <summary>
    /// Veritabanına kaydedilen tekil bir aktivite/sistem olayı.
    /// </summary>
    public class ActivityEvent
    {
        public long Id { get; set; }

        /// <summary>Olayın ait olduğu Windows kullanıcı adı.</summary>
        public string UserName { get; set; }

        /// <summary>Olay türü.</summary>
        public ActivityEventType EventType { get; set; }

        /// <summary>Olayın gerçekleştiği yerel zaman.</summary>
        public DateTime Timestamp { get; set; }

        /// <summary>İsteğe bağlı ek açıklama (örn. uyku sebebi, oturum no).</summary>
        public string Details { get; set; }

        /// <summary>Olayın geldiği makine adı (agent gönderir); eski kayıtlarda null olabilir.</summary>
        public string Machine { get; set; }

        public ActivityEvent()
        {
        }

        public ActivityEvent(string userName, ActivityEventType eventType, DateTime timestamp, string details = null, string machine = null)
        {
            UserName = userName;
            EventType = eventType;
            Timestamp = timestamp;
            Details = details;
            Machine = machine;
        }

        /// <summary>Olay türünün Türkçe, kullanıcıya gösterilecek karşılığı.</summary>
        public string EventTypeLabel
        {
            get { return EventTypeLabels.For(EventType); }
        }
    }

    /// <summary>Olay türleri için Türkçe etiketler.</summary>
    public static class EventTypeLabels
    {
        public static string For(ActivityEventType type)
        {
            switch (type)
            {
                case ActivityEventType.Login: return "Giriş";
                case ActivityEventType.Logout: return "Çıkış";
                case ActivityEventType.Lock: return "Ekran Kilitlendi";
                case ActivityEventType.Unlock: return "Kilit Açıldı";
                case ActivityEventType.Sleep: return "Uyku Modu";
                case ActivityEventType.Wake: return "Uyandı";
                case ActivityEventType.ShuttingDown: return "Kapanıyor";
                case ActivityEventType.ActiveStart: return "Aktif Oldu";
                case ActivityEventType.IdleStart: return "Pasife Geçti";
                default: return type.ToString();
            }
        }
    }
}
