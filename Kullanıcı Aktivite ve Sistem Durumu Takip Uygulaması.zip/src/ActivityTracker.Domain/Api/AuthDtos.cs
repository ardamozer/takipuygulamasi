namespace ActivityTracker.Domain.Api
{
    /// <summary>Panel giriş isteği.</summary>
    public class LoginRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

    /// <summary>Başarılı girişin yanıtı: oturum jetonu + rol bilgisi.</summary>
    public class LoginResponse
    {
        public string Token { get; set; }
        public string Username { get; set; }
        public string DisplayName { get; set; }

        /// <summary>"User" veya "Admin".</summary>
        public string Role { get; set; }
    }
}
