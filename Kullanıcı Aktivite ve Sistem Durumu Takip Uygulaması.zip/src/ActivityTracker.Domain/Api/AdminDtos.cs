namespace ActivityTracker.Domain.Api
{
    /// <summary>Yönetici tarafından yeni hesap oluşturma isteği.</summary>
    public class CreateUserRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string DisplayName { get; set; }

        /// <summary>"User" veya "Admin" (boşsa User).</summary>
        public string Role { get; set; }
    }
}
