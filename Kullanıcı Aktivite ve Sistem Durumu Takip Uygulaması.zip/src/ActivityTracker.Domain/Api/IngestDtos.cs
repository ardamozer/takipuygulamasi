using System;
using System.Collections.Generic;
using ActivityTracker.Domain.Enums;

namespace ActivityTracker.Domain.Api
{
    /// <summary>Agent'ın gönderdiği tekil olay.</summary>
    public class EventDto
    {
        public string UserName { get; set; }
        public string Machine { get; set; }
        public ActivityEventType EventType { get; set; }
        public DateTime Timestamp { get; set; }
        public string Details { get; set; }
    }

    /// <summary>Agent'ın toplu olarak gönderdiği olay paketi.</summary>
    public class EventBatchDto
    {
        public List<EventDto> Events { get; set; } = new List<EventDto>();
    }

    /// <summary>Oturum başlatma isteği.</summary>
    public class SessionStartDto
    {
        public string UserName { get; set; }
        public string Machine { get; set; }
        public DateTime LoginTime { get; set; }
    }

    /// <summary>Oturum başlatma yanıtı.</summary>
    public class SessionStartResponse
    {
        public long SessionId { get; set; }
    }

    /// <summary>Oturum kapatma isteği.</summary>
    public class SessionEndDto
    {
        public long SessionId { get; set; }
        public DateTime LogoutTime { get; set; }
    }
}
