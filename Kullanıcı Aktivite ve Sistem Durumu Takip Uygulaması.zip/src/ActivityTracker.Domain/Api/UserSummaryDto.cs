using System;

namespace ActivityTracker.Domain.Api
{
    /// <summary>Yönetici kullanıcı listesinde gösterilen özet satır.</summary>
    public class UserSummaryDto
    {
        /// <summary>Windows kullanıcı adı (loglar bununla anahtarlanır).</summary>
        public string UserName { get; set; }

        public string DisplayName { get; set; }

        /// <summary>Bilinen en son makine adı.</summary>
        public string Machine { get; set; }

        /// <summary>En son aktivite (ActiveStart) zamanı; yoksa null.</summary>
        public DateTime? LastActivity { get; set; }

        /// <summary>Anlık durum metni (Aktif / Pasif / Kilitli / Çevrimdışı vb.).</summary>
        public string Status { get; set; }
    }
}
