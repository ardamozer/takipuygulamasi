using System;
using ActivityTracker.Data.Repositories;
using ActivityTracker.Domain.Enums;
using ActivityTracker.Domain.Models;
using ActivityTracker.Services.Monitoring;

namespace ActivityTracker.Services
{
    /// <summary>Kullanıcının anlık durumu.</summary>
    public enum UserStatus
    {
        Active,
        Idle,
        Locked,
        Sleeping,
        Offline
    }

    /// <summary>
    /// Tüm izleyicileri (oturum, güç, boşta) yönetir; üretilen olayları
    /// veritabanına yazar ve UI'ye anlık durum bildirir.
    /// </summary>
    public class TrackingService
    {
        private readonly IEventRepository _eventRepository;
        private readonly ISessionRepository _sessionRepository;

        private readonly SessionMonitor _sessionMonitor;
        private readonly PowerMonitor _powerMonitor;
        private readonly IdleMonitor _idleMonitor;

        private readonly string _userName;
        private long _currentSessionId;
        private bool _running;

        /// <summary>Yeni bir olay kaydedildiğinde tetiklenir (UI yenilemek için).</summary>
        public event EventHandler<ActivityEvent> EventPersisted;

        /// <summary>Kullanıcı durumu değiştiğinde tetiklenir.</summary>
        public event EventHandler<UserStatus> StatusChanged;

        public TrackingService(IEventRepository eventRepository, ISessionRepository sessionRepository)
        {
            _eventRepository = eventRepository;
            _sessionRepository = sessionRepository;
            _userName = Environment.UserName;

            _sessionMonitor = new SessionMonitor();
            _powerMonitor = new PowerMonitor();
            _idleMonitor = new IdleMonitor();

            _sessionMonitor.EventOccurred += OnMonitorEvent;
            _powerMonitor.EventOccurred += OnMonitorEvent;
            _idleMonitor.EventOccurred += OnMonitorEvent;
        }

        public string UserName { get { return _userName; } }

        public UserStatus CurrentStatus { get; private set; }

        public IdleMonitor IdleMonitor { get { return _idleMonitor; } }

        /// <summary>İzlemeyi başlatır; giriş olayı ve yeni oturum kaydı oluşturur.</summary>
        public void Start()
        {
            if (_running) return;

            // Önceki çalışmadan kapatılmamış oturum kaldıysa kapat.
            var open = _sessionRepository.GetOpenSession(_userName);
            if (open != null)
                _sessionRepository.EndSession(open.Id, DateTime.Now);

            _currentSessionId = _sessionRepository.StartSession(_userName, DateTime.Now);
            PersistEvent(new ActivityEventArgs(ActivityEventType.Login, DateTime.Now, "Uygulama başlatıldı"));
            UpdateStatus(UserStatus.Active);

            _sessionMonitor.Start();
            _powerMonitor.Start();
            _idleMonitor.Start();

            _running = true;
        }

        /// <summary>İzlemeyi durdurur; çıkış olayı ve oturum kapanışı yazar.</summary>
        public void Stop()
        {
            if (!_running) return;

            _sessionMonitor.Stop();
            _powerMonitor.Stop();
            _idleMonitor.Stop();

            PersistEvent(new ActivityEventArgs(ActivityEventType.Logout, DateTime.Now, "Uygulama kapatıldı"));
            if (_currentSessionId > 0)
                _sessionRepository.EndSession(_currentSessionId, DateTime.Now);

            UpdateStatus(UserStatus.Offline);
            _running = false;
        }

        private void OnMonitorEvent(object sender, ActivityEventArgs e)
        {
            PersistEvent(e);
            UpdateStatus(MapStatus(e.EventType));
        }

        private void PersistEvent(ActivityEventArgs e)
        {
            var entity = new ActivityEvent(_userName, e.EventType, e.Timestamp, e.Details);
            try
            {
                _eventRepository.Add(entity);
            }
            catch
            {
                // Kapanış sırasında DB erişilemezse uygulamayı düşürme.
            }
            EventPersisted?.Invoke(this, entity);
        }

        private static UserStatus MapStatus(ActivityEventType type)
        {
            switch (type)
            {
                case ActivityEventType.Lock: return UserStatus.Locked;
                case ActivityEventType.Sleep: return UserStatus.Sleeping;
                case ActivityEventType.IdleStart: return UserStatus.Idle;
                case ActivityEventType.ShuttingDown:
                case ActivityEventType.Logout: return UserStatus.Offline;
                default: return UserStatus.Active; // Login, Unlock, Wake, ActiveStart
            }
        }

        private void UpdateStatus(UserStatus status)
        {
            CurrentStatus = status;
            StatusChanged?.Invoke(this, status);
        }
    }
}
