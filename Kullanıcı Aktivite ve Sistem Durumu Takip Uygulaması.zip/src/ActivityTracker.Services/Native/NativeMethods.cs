using System;
using System.Runtime.InteropServices;

namespace ActivityTracker.Services.Native
{
    /// <summary>
    /// Kullanıcı boşta kalma süresini ölçmek için kullanılan Win32 API çağrıları.
    /// GetLastInputInfo, son klavye/mouse girdisinden bu yana geçen süreyi verir.
    /// </summary>
    internal static class NativeMethods
    {
        [StructLayout(LayoutKind.Sequential)]
        internal struct LASTINPUTINFO
        {
            public uint cbSize;
            public uint dwTime;
        }

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

        [DllImport("kernel32.dll")]
        internal static extern uint GetTickCount();

        /// <summary>
        /// Son kullanıcı girdisinden (klavye/mouse) bu yana geçen süreyi döner.
        /// </summary>
        public static TimeSpan GetIdleTime()
        {
            var lastInput = new LASTINPUTINFO();
            lastInput.cbSize = (uint)Marshal.SizeOf(lastInput);

            if (!GetLastInputInfo(ref lastInput))
                return TimeSpan.Zero;

            // GetTickCount sarması (~49 gün) durumunda negatif olmaması için unchecked.
            uint idleMilliseconds = unchecked(GetTickCount() - lastInput.dwTime);
            return TimeSpan.FromMilliseconds(idleMilliseconds);
        }
    }
}
