using System;
using System.Collections.Generic;
using ActivityTracker.Domain.Enums;
using ActivityTracker.Domain.Models;

namespace ActivityTracker.Services
{
    /// <summary>
    /// Bir günün olay zaman çizelgesini yürüyerek toplam / aktif / pasif /
    /// kilitli / uyku sürelerini hesaplar. Saf (yan etkisiz) hesaplama olduğu
    /// için arayüze ihtiyaç olmadan test edilebilir.
    /// </summary>
    public class WorkTimeCalculator
    {
        /// <summary>İki olay arasında bilgisayarın bulunduğu durum.</summary>
        private enum State
        {
            Off,     // Kapalı / oturum kapalı (sayılmaz)
            Active,  // Kullanıcı aktif
            Idle,    // Açık ama hareketsiz
            Locked,  // Ekran kilitli
            Sleep    // Uyku modu
        }

        /// <summary>
        /// Verilen güne ait olaylardan günlük raporu üretir.
        /// </summary>
        /// <param name="userName">Kullanıcı adı.</param>
        /// <param name="date">Rapor günü.</param>
        /// <param name="events">O güne ait, zamana göre sıralı olaylar.</param>
        /// <param name="now">Bugün için bitiş referansı (varsayılan DateTime.Now).</param>
        public DailyReport Calculate(string userName, DateTime date, IList<ActivityEvent> events, DateTime? now = null)
        {
            var report = new DailyReport { Date = date.Date, UserName = userName };

            var dayStart = date.Date;
            var dayEnd = dayStart.AddDays(1);
            var reference = now ?? DateTime.Now;

            // Bugünün raporunda son aralığı "şu an"a kadar; geçmiş günlerde gün sonuna kadar say.
            var boundary = (reference >= dayStart && reference < dayEnd) ? reference : dayEnd;

            var active = TimeSpan.Zero;
            var idle = TimeSpan.Zero;
            var locked = TimeSpan.Zero;
            var sleep = TimeSpan.Zero;

            var currentState = State.Off;
            DateTime? lastTime = null;

            foreach (var ev in events)
            {
                // Önceki durumda geçen süreyi ilgili kovaya ekle.
                if (lastTime.HasValue)
                {
                    var span = ev.Timestamp - lastTime.Value;
                    if (span > TimeSpan.Zero)
                        Accumulate(currentState, span, ref active, ref idle, ref locked, ref sleep);
                }

                currentState = NextState(ev.EventType, currentState);

                if (IsActivity(ev.EventType))
                {
                    if (report.FirstLogin == null && ev.EventType == ActivityEventType.Login)
                        report.FirstLogin = ev.Timestamp;
                    report.LastActivity = ev.Timestamp;
                }

                lastTime = ev.Timestamp;
            }

            // Son olaydan sınıra kadar olan açık aralığı ekle.
            if (lastTime.HasValue && currentState != State.Off && boundary > lastTime.Value)
            {
                Accumulate(currentState, boundary - lastTime.Value, ref active, ref idle, ref locked, ref sleep);
            }

            report.ActiveTime = active;
            report.IdleTime = idle;
            report.LockedTime = locked;
            report.SleepTime = sleep;
            // Toplam = bilgisayar başında geçen süre (aktif + pasif + kilitli), uyku hariç.
            report.TotalTime = active + idle + locked;

            if (report.FirstLogin == null && events.Count > 0)
                report.FirstLogin = events[0].Timestamp;

            return report;
        }

        /// <summary>Bir haftanın (7 gün) günlük raporlarını üretir.</summary>
        public IList<DailyReport> CalculateWeek(string userName, DateTime weekStart,
            Func<DateTime, IList<ActivityEvent>> eventsProvider, DateTime? now = null)
        {
            var reports = new List<DailyReport>();
            for (int i = 0; i < 7; i++)
            {
                var day = weekStart.Date.AddDays(i);
                reports.Add(Calculate(userName, day, eventsProvider(day), now));
            }
            return reports;
        }

        private static State NextState(ActivityEventType type, State current)
        {
            switch (type)
            {
                case ActivityEventType.Login:
                case ActivityEventType.ActiveStart:
                case ActivityEventType.Unlock:
                    return State.Active;
                case ActivityEventType.IdleStart:
                    return State.Idle;
                case ActivityEventType.Lock:
                    return State.Locked;
                case ActivityEventType.Sleep:
                    return State.Sleep;
                case ActivityEventType.Wake:
                    return State.Idle; // Uyandı; aktivite gelene kadar pasif say.
                case ActivityEventType.ShuttingDown:
                case ActivityEventType.Logout:
                    return State.Off;
                default:
                    return current;
            }
        }

        private static bool IsActivity(ActivityEventType type)
        {
            return type == ActivityEventType.Login
                || type == ActivityEventType.ActiveStart
                || type == ActivityEventType.Unlock;
        }

        private static void Accumulate(State state, TimeSpan span,
            ref TimeSpan active, ref TimeSpan idle, ref TimeSpan locked, ref TimeSpan sleep)
        {
            switch (state)
            {
                case State.Active: active += span; break;
                case State.Idle: idle += span; break;
                case State.Locked: locked += span; break;
                case State.Sleep: sleep += span; break;
            }
        }
    }
}
