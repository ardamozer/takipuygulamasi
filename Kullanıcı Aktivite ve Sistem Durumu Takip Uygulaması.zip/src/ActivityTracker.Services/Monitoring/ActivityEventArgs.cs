using System;
using ActivityTracker.Domain.Enums;

namespace ActivityTracker.Services.Monitoring
{
    /// <summary>İzleyicilerin yeni bir olay ürettiğinde taşıdığı veri.</summary>
    public class ActivityEventArgs : EventArgs
    {
        public ActivityEventType EventType { get; }
        public DateTime Timestamp { get; }
        public string Details { get; }

        public ActivityEventArgs(ActivityEventType eventType, DateTime timestamp, string details = null)
        {
            EventType = eventType;
            Timestamp = timestamp;
            Details = details;
        }
    }

    /// <summary>Tüm sistem/aktivite izleyicilerinin ortak arayüzü.</summary>
    public interface IMonitor
    {
        /// <summary>Bir olay tespit edildiğinde tetiklenir.</summary>
        event EventHandler<ActivityEventArgs> EventOccurred;

        void Start();
        void Stop();
    }
}
