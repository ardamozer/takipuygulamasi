using System;
using ActivityTracker.Domain.Enums;
using Microsoft.Win32;

namespace ActivityTracker.Services.Monitoring
{
    /// <summary>
    /// Uyku/uyanma ve kapanma/yeniden başlatma olaylarını izler.
    /// PowerModeChanged → uyku/uyanma, SessionEnding → kapanma/oturum sonu.
    /// </summary>
    public class PowerMonitor : IMonitor
    {
        public event EventHandler<ActivityEventArgs> EventOccurred;

        private bool _running;

        public void Start()
        {
            if (_running) return;
            SystemEvents.PowerModeChanged += OnPowerModeChanged;
            SystemEvents.SessionEnding += OnSessionEnding;
            _running = true;
        }

        public void Stop()
        {
            if (!_running) return;
            SystemEvents.PowerModeChanged -= OnPowerModeChanged;
            SystemEvents.SessionEnding -= OnSessionEnding;
            _running = false;
        }

        private void OnPowerModeChanged(object sender, PowerModeChangedEventArgs e)
        {
            var now = DateTime.Now;
            if (e.Mode == PowerModes.Suspend)
                Raise(ActivityEventType.Sleep, now, "Bilgisayar uyku moduna geçti");
            else if (e.Mode == PowerModes.Resume)
                Raise(ActivityEventType.Wake, now, "Bilgisayar uykudan uyandı");
        }

        private void OnSessionEnding(object sender, SessionEndingEventArgs e)
        {
            var reason = e.Reason == SessionEndReasons.SystemShutdown
                ? "Sistem kapatılıyor / yeniden başlatılıyor"
                : "Oturum sonlandırılıyor";
            Raise(ActivityEventType.ShuttingDown, DateTime.Now, reason);
        }

        private void Raise(ActivityEventType type, DateTime time, string details)
        {
            EventOccurred?.Invoke(this, new ActivityEventArgs(type, time, details));
        }
    }
}
