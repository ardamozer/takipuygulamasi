using System;
using ActivityTracker.Domain.Enums;
using Microsoft.Win32;

namespace ActivityTracker.Services.Monitoring
{
    /// <summary>
    /// Ekran kilidi/kilit açma ve oturum açma/kapama olaylarını izler.
    /// Windows'un SystemEvents.SessionSwitch olayını dinler (mesaj döngüsü gerekir).
    /// </summary>
    public class SessionMonitor : IMonitor
    {
        public event EventHandler<ActivityEventArgs> EventOccurred;

        private bool _running;

        public void Start()
        {
            if (_running) return;
            SystemEvents.SessionSwitch += OnSessionSwitch;
            _running = true;
        }

        public void Stop()
        {
            if (!_running) return;
            SystemEvents.SessionSwitch -= OnSessionSwitch;
            _running = false;
        }

        private void OnSessionSwitch(object sender, SessionSwitchEventArgs e)
        {
            var now = DateTime.Now;
            switch (e.Reason)
            {
                case SessionSwitchReason.SessionLock:
                    Raise(ActivityEventType.Lock, now, "Ekran kilitlendi");
                    break;
                case SessionSwitchReason.SessionUnlock:
                    Raise(ActivityEventType.Unlock, now, "Ekran kilidi açıldı");
                    break;
                case SessionSwitchReason.SessionLogon:
                case SessionSwitchReason.RemoteConnect:
                    Raise(ActivityEventType.Login, now, "Oturum açıldı");
                    break;
                case SessionSwitchReason.SessionLogoff:
                case SessionSwitchReason.RemoteDisconnect:
                    Raise(ActivityEventType.Logout, now, "Oturum kapatıldı");
                    break;
            }
        }

        private void Raise(ActivityEventType type, DateTime time, string details)
        {
            EventOccurred?.Invoke(this, new ActivityEventArgs(type, time, details));
        }
    }
}
