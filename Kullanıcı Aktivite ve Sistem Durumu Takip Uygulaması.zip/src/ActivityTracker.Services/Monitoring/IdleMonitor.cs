using System;
using System.Timers;
using ActivityTracker.Domain.Enums;
using ActivityTracker.Services.Native;

namespace ActivityTracker.Services.Monitoring
{
    /// <summary>
    /// Klavye/mouse hareketsizliğine göre kullanıcının aktif/pasif durumunu izler.
    /// Belirlenen eşik (varsayılan 60 sn) kadar girdi olmazsa "pasif", yeni girdi
    /// gelince "aktif" olayı üretir.
    /// </summary>
    public class IdleMonitor : IMonitor
    {
        public event EventHandler<ActivityEventArgs> EventOccurred;

        private readonly Timer _timer;
        private TimeSpan _idleThreshold;
        private bool _isIdle;
        private bool _running;

        /// <param name="idleThresholdSeconds">Pasif sayılmak için gereken hareketsizlik süresi (sn).</param>
        /// <param name="pollIntervalMs">Kontrol aralığı (ms).</param>
        public IdleMonitor(int idleThresholdSeconds = 60, double pollIntervalMs = 2000)
        {
            _idleThreshold = TimeSpan.FromSeconds(idleThresholdSeconds);
            _timer = new Timer(pollIntervalMs);
            _timer.Elapsed += OnTick;
            _timer.AutoReset = true;
        }

        /// <summary>Şu an kullanıcı pasif (boşta) mı?</summary>
        public bool IsIdle
        {
            get { return _isIdle; }
        }

        /// <summary>Son girdiden bu yana geçen anlık boşta süresi.</summary>
        public TimeSpan CurrentIdleTime
        {
            get { return NativeMethods.GetIdleTime(); }
        }

        /// <summary>Pasif eşiğini çalışma sırasında günceller.</summary>
        public void SetIdleThreshold(int seconds)
        {
            if (seconds < 5) seconds = 5;
            _idleThreshold = TimeSpan.FromSeconds(seconds);
        }

        public void Start()
        {
            if (_running) return;
            _isIdle = false;
            _timer.Start();
            _running = true;
        }

        public void Stop()
        {
            if (!_running) return;
            _timer.Stop();
            _running = false;
        }

        private void OnTick(object sender, ElapsedEventArgs e)
        {
            var idle = NativeMethods.GetIdleTime();
            var now = DateTime.Now;

            if (!_isIdle && idle >= _idleThreshold)
            {
                _isIdle = true;
                Raise(ActivityEventType.IdleStart, now, "Kullanıcı hareketsiz");
            }
            else if (_isIdle && idle < _idleThreshold)
            {
                _isIdle = false;
                Raise(ActivityEventType.ActiveStart, now, "Kullanıcı tekrar aktif");
            }
        }

        private void Raise(ActivityEventType type, DateTime time, string details)
        {
            EventOccurred?.Invoke(this, new ActivityEventArgs(type, time, details));
        }
    }
}
