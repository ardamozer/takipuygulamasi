using System;
using System.Collections.Generic;
using ActivityTracker.Data.Repositories;
using ActivityTracker.Domain.Api;
using ActivityTracker.Domain.Enums;
using ActivityTracker.Domain.Models;
using ActivityTracker.Services;

namespace ActivityTracker.Backend.Reports
{
    /// <summary>
    /// Depolardan veriyi çekip WorkTimeCalculator ile rapor/özet üretir.
    /// Raporlar sunucuda hesaplanır ki tüm istemcilerde tutarlı olsun.
    /// </summary>
    public class ReportService
    {
        private readonly IEventRepository _events;
        private readonly IUserRepository _users;
        private readonly WorkTimeCalculator _calculator = new WorkTimeCalculator();

        public ReportService(IEventRepository events, IUserRepository users)
        {
            _events = events;
            _users = users;
        }

        public DailyReport DailyReport(string userName, DateTime date)
        {
            var events = _events.GetByDate(userName, date);
            return _calculator.Calculate(userName, date, events);
        }

        public IList<ActivityEvent> Events(string userName, DateTime date)
        {
            return _events.GetByDate(userName, date);
        }

        public IList<DailyReport> Week(string userName, DateTime weekStart)
        {
            return _calculator.CalculateWeek(userName, weekStart, day => _events.GetByDate(userName, day));
        }

        /// <summary>Yönetici görünümü: log üreten tüm kullanıcıların özetleri.</summary>
        public IList<UserSummaryDto> UserSummaries()
        {
            var accounts = new Dictionary<string, User>(StringComparer.OrdinalIgnoreCase);
            foreach (var u in _users.ListAll())
                accounts[u.Username] = u;

            // Hem hesabı olan hem de log üreten kullanıcıları birleştir.
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var n in _events.GetDistinctUsers()) names.Add(n);
            foreach (var u in accounts.Keys) names.Add(u);

            var list = new List<UserSummaryDto>();
            foreach (var name in names)
            {
                var last = _events.GetLastEvent(name);
                accounts.TryGetValue(name, out var account);
                list.Add(new UserSummaryDto
                {
                    UserName = name,
                    DisplayName = account?.DisplayName ?? name,
                    Machine = last?.Machine,
                    LastActivity = _events.GetLastActivity(name),
                    Status = StatusFor(last)
                });
            }
            list.Sort((a, b) => string.Compare(a.UserName, b.UserName, StringComparison.OrdinalIgnoreCase));
            return list;
        }

        /// <summary>Son olaydan anlık durum metni türetir.</summary>
        private static string StatusFor(ActivityEvent last)
        {
            if (last == null) return "Veri yok";

            // Son olay çok eskiyse çevrimdışı say.
            if ((DateTime.Now - last.Timestamp) > TimeSpan.FromMinutes(10)
                && last.EventType != ActivityEventType.Lock
                && last.EventType != ActivityEventType.Sleep)
                return "Çevrimdışı";

            switch (last.EventType)
            {
                case ActivityEventType.IdleStart: return "Pasif (Boşta)";
                case ActivityEventType.Lock: return "Ekran Kilitli";
                case ActivityEventType.Sleep: return "Uyku Modu";
                case ActivityEventType.Logout:
                case ActivityEventType.ShuttingDown: return "Çevrimdışı";
                default: return "Aktif";
            }
        }
    }
}
