using System.Web.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Owin;

namespace ActivityTracker.Backend
{
    /// <summary>OWIN başlangıç sınıfı: Web API rotaları ve JSON ayarları.</summary>
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            var config = new HttpConfiguration();
            config.MapHttpAttributeRoutes();

            // Yalnızca JSON döndür; enum'ları okunur metin yerine sayı olarak bırak
            // (istemciler aynı DTO'ları kullanıyor, tutarlı kalsın).
            var json = config.Formatters.JsonFormatter;
            json.SerializerSettings.NullValueHandling = NullValueHandling.Include;
            json.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Local;

            config.Formatters.Remove(config.Formatters.XmlFormatter);

            app.UseWebApi(config);
        }
    }
}
