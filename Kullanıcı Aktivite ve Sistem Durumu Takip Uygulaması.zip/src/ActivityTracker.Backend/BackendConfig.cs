using System;
using System.IO;

namespace ActivityTracker.Backend
{
    /// <summary>
    /// Backend yapılandırması. Varsayılanlar koddadır; exe yanındaki backend.ini
    /// (key=value) ile geçersiz kılınabilir.
    /// </summary>
    public static class BackendConfig
    {
        /// <summary>API'nin dinleyeceği adres.</summary>
        public static string Url { get; private set; } = "http://localhost:5005";

        /// <summary>Agent'ların ingest uçları için paylaşılan anahtar.</summary>
        public static string AgentApiKey { get; private set; } = "hetabil-agent-key";

        /// <summary>Oturum jetonu geçerlilik süresi.</summary>
        public static TimeSpan TokenLifetime { get; private set; } = TimeSpan.FromHours(12);

        /// <summary>SQLite veritabanının tutulacağı klasör (exe yanında data\).</summary>
        public static string DataDirectory { get; private set; } =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data");

        /// <summary>backend.ini varsa okur; ayrıca komut satırı argümanını URL olarak alır.</summary>
        public static void Load(string[] args)
        {
            var iniPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "backend.ini");
            if (File.Exists(iniPath))
            {
                foreach (var raw in File.ReadAllLines(iniPath))
                {
                    var line = raw.Trim();
                    if (line.Length == 0 || line.StartsWith("#") || line.StartsWith(";")) continue;
                    var idx = line.IndexOf('=');
                    if (idx <= 0) continue;
                    var key = line.Substring(0, idx).Trim();
                    var val = line.Substring(idx + 1).Trim();
                    Apply(key, val);
                }
            }

            // İlk argüman verilirse URL olarak kullan.
            if (args != null && args.Length > 0 && !string.IsNullOrWhiteSpace(args[0]))
                Url = args[0].Trim();
        }

        private static void Apply(string key, string val)
        {
            switch (key.ToLowerInvariant())
            {
                case "url": Url = val; break;
                case "agentapikey": AgentApiKey = val; break;
                case "datadirectory": DataDirectory = val; break;
                case "tokenhours":
                    if (double.TryParse(val, out var h)) TokenLifetime = TimeSpan.FromHours(h);
                    break;
            }
        }
    }
}
