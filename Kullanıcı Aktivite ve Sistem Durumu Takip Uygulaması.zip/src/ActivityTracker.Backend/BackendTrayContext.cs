using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace ActivityTracker.Backend
{
    /// <summary>
    /// Backend'i konsol olmadan, sistem tepsisinde çalıştıran uygulama bağlamı.
    /// OWIN self-host (WebApp.Start) açık kalır; "Çıkış" ile düzgün kapatılır.
    /// </summary>
    public class BackendTrayContext : ApplicationContext
    {
        private readonly NotifyIcon _trayIcon;
        private readonly IDisposable _webApp;

        public BackendTrayContext(IDisposable webApp)
        {
            _webApp = webApp;

            var menu = new ContextMenuStrip();
            menu.Items.Add(new ToolStripMenuItem("Hetabil Backend (çalışıyor)") { Enabled = false });
            menu.Items.Add(new ToolStripMenuItem("Adres: " + BackendConfig.Url) { Enabled = false });
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(new ToolStripMenuItem("Çıkış", null, (s, e) => ExitBackend()));

            _trayIcon = new NotifyIcon
            {
                Icon = LoadIcon(),
                Visible = true,
                Text = "Hetabil Backend",
                ContextMenuStrip = menu
            };

            _trayIcon.ShowBalloonTip(3000, "Hetabil Backend",
                "Çalışıyor: " + BackendConfig.Url, ToolTipIcon.Info);
        }

        private void ExitBackend()
        {
            try { _webApp.Dispose(); } catch { /* yut */ }
            _trayIcon.Visible = false;
            _trayIcon.Dispose();
            ExitThread();
        }

        private static Icon LoadIcon()
        {
            try
            {
                return Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location)
                       ?? SystemIcons.Application;
            }
            catch
            {
                return SystemIcons.Application;
            }
        }
    }
}
