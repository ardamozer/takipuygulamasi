using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using ActivityTracker.Data;
using ActivityTracker.Data.Repositories;
using ActivityTracker.Data.Security;
using ActivityTracker.Domain.Enums;
using ActivityTracker.Domain.Models;
using Microsoft.Owin.Hosting;

namespace ActivityTracker.Backend
{
    internal static class Program
    {
        // Komut satırından çalıştırıldığında çağıran konsola yazabilmek için.
        [DllImport("kernel32.dll")]
        private static extern bool AttachConsole(int processId);
        private const int ATTACH_PARENT_PROCESS = -1;

        private static Mutex _mutex;

        [STAThread]
        private static void Main(string[] args)
        {
            var command = (args != null && args.Length > 0) ? args[0].ToLowerInvariant() : null;
            var isCommand = command == "set-password" || command == "add-user";

            // Komut çalıştırılıyorsa ilk argümanı URL sanma.
            BackendConfig.Load(isCommand ? new string[0] : args);

            // Merkezî veritabanını backend yanındaki data\ klasörüne yerleştir.
            Directory.CreateDirectory(BackendConfig.DataDirectory);
            DatabaseConfig.DatabasePath = Path.Combine(BackendConfig.DataDirectory, "activity.db");
            DatabaseInitializer.Initialize();

            if (isCommand)
            {
                // WinExe olduğu için konsolu yoktur; çağıran komut istemine bağlan.
                AttachConsole(ATTACH_PARENT_PROCESS);
                Console.WriteLine();
                RunCommand(command, args);
                return;
            }

            // Tek örnek çalışsın (çift açmayı engelle).
            _mutex = new Mutex(true, "HetabilActivityBackend_SingleInstance", out var createdNew);
            if (!createdNew)
            {
                MessageBox.Show("Backend zaten çalışıyor.", "Hetabil Backend",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            IDisposable webApp;
            try
            {
                webApp = WebApp.Start<Startup>(BackendConfig.Url);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "API başlatılamadı:\n\n" + ex.Message +
                    "\n\nİpucu: 'http://+:5005' gibi ağa açık bir adres için bir kez " +
                    "Backend-Agi-Ac.bat (yönetici) çalıştırılmalıdır.",
                    "Hetabil Backend - Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Application.Run(new BackendTrayContext(webApp));

            GC.KeepAlive(_mutex);
        }

        /// <summary>Sunucuyu başlatmadan çalışan yardımcı komutlar (parola/hesap yönetimi).</summary>
        private static void RunCommand(string command, string[] args)
        {
            var users = new UserRepository();

            if (command == "set-password")
            {
                if (args.Length < 3)
                {
                    Console.WriteLine("Kullanım: ActivityTracker.Backend.exe set-password <kullanıcı> <yeni-parola>");
                    return;
                }

                var username = args[1];
                var password = args[2];
                var user = users.GetByUsername(username);
                if (user == null)
                {
                    Console.WriteLine("Kullanıcı bulunamadı: " + username);
                    return;
                }

                PasswordHasher.CreateHash(password, out var hash, out var salt);
                users.SetPassword(username, hash, salt);
                Console.WriteLine("Parola güncellendi: " + username);
                return;
            }

            if (command == "add-user")
            {
                if (args.Length < 3)
                {
                    Console.WriteLine("Kullanım: ActivityTracker.Backend.exe add-user <kullanıcı> <parola> [admin|user] [Görünen Ad]");
                    Console.WriteLine("Not: Normal kullanıcının adı, izlenen Windows kullanıcı adıyla aynı olmalı (kendi verisini görmesi için).");
                    return;
                }

                var username = args[1];
                var password = args[2];
                var role = (args.Length >= 4 && args[3].Equals("admin", StringComparison.OrdinalIgnoreCase))
                    ? UserRole.Admin : UserRole.User;
                var displayName = args.Length >= 5 ? args[4] : username;

                if (users.GetByUsername(username) != null)
                {
                    Console.WriteLine("Bu kullanıcı zaten var: " + username + " (parolayı değiştirmek için 'set-password' kullanın)");
                    return;
                }

                PasswordHasher.CreateHash(password, out var hash, out var salt);
                users.Add(new User
                {
                    Username = username,
                    DisplayName = displayName,
                    PasswordHash = hash,
                    PasswordSalt = salt,
                    Role = role,
                    CreatedAt = DateTime.Now
                });
                Console.WriteLine("Hesap oluşturuldu: " + username + " (" + role + ")");
            }
        }
    }
}
