using System.Net;
using System.Web.Http;
using ActivityTracker.Data.Repositories;
using ActivityTracker.Data.Security;
using ActivityTracker.Domain.Api;

namespace ActivityTracker.Backend.Controllers
{
    [RoutePrefix("api/auth")]
    public class AuthController : ApiController
    {
        private readonly IUserRepository _users = new UserRepository();

        [HttpPost, Route("login")]
        public IHttpActionResult Login([FromBody] LoginRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.Username))
                return BadRequest("Kullanıcı adı ve parola gerekli.");

            var user = _users.GetByUsername(request.Username);
            if (user == null || !PasswordHasher.Verify(request.Password, user.PasswordHash, user.PasswordSalt))
                return Content(HttpStatusCode.Unauthorized, "Kullanıcı adı veya parola hatalı.");

            var token = Auth.TokenStore.Issue(user.Username, user.Role);
            return Ok(new LoginResponse
            {
                Token = token,
                Username = user.Username,
                DisplayName = user.DisplayName ?? user.Username,
                Role = user.Role.ToString()
            });
        }
    }
}
