using System.Web.Http;
using ActivityTracker.Backend.Auth;
using ActivityTracker.Backend.Reports;
using ActivityTracker.Data.Repositories;

namespace ActivityTracker.Backend.Controllers
{
    /// <summary>Giriş yapan kullanıcının kendi verisi (Bearer jeton gerekir).</summary>
    [TokenAuthorize]
    [RoutePrefix("api/me")]
    public class MeController : ApiController
    {
        private readonly ReportService _reports =
            new ReportService(new EventRepository(), new UserRepository());

        [HttpGet, Route("report")]
        public IHttpActionResult Report(string date = null)
        {
            return Ok(_reports.DailyReport(this.CurrentUser(), DateArg.Parse(date)));
        }

        [HttpGet, Route("events")]
        public IHttpActionResult Events(string date = null)
        {
            return Ok(_reports.Events(this.CurrentUser(), DateArg.Parse(date)));
        }

        [HttpGet, Route("week")]
        public IHttpActionResult Week(string date = null)
        {
            return Ok(_reports.Week(this.CurrentUser(), DateArg.Parse(date)));
        }
    }
}
