using System;
using System.Globalization;

namespace ActivityTracker.Backend.Controllers
{
    /// <summary>Sorgu tarihini (yyyy-MM-dd) çözer; boşsa bugünü döner.</summary>
    internal static class DateArg
    {
        public static DateTime Parse(string date)
        {
            if (!string.IsNullOrWhiteSpace(date) &&
                DateTime.TryParseExact(date, "yyyy-MM-dd", CultureInfo.InvariantCulture,
                    DateTimeStyles.None, out var d))
                return d.Date;
            return DateTime.Today;
        }
    }
}
