using System.Web.Http;
using ActivityTracker.Backend.Auth;
using ActivityTracker.Data.Repositories;
using ActivityTracker.Domain.Api;
using ActivityTracker.Domain.Models;

namespace ActivityTracker.Backend.Controllers
{
    /// <summary>Agent'lardan gelen olay/oturum verisini alır (X-Agent-Key korumalı).</summary>
    [AgentKey]
    [RoutePrefix("api/ingest")]
    public class IngestController : ApiController
    {
        private readonly IEventRepository _events = new EventRepository();
        private readonly ISessionRepository _sessions = new SessionRepository();

        [HttpPost, Route("events")]
        public IHttpActionResult PostEvents([FromBody] EventBatchDto batch)
        {
            if (batch?.Events == null || batch.Events.Count == 0)
                return Ok(new { saved = 0 });

            var saved = 0;
            foreach (var dto in batch.Events)
            {
                if (string.IsNullOrWhiteSpace(dto.UserName)) continue;
                _events.Add(new ActivityEvent(dto.UserName, dto.EventType, dto.Timestamp, dto.Details, dto.Machine));
                saved++;
            }
            return Ok(new { saved });
        }

        [HttpPost, Route("session/start")]
        public IHttpActionResult StartSession([FromBody] SessionStartDto dto)
        {
            if (dto == null || string.IsNullOrWhiteSpace(dto.UserName))
                return BadRequest("UserName gerekli.");

            var id = _sessions.StartSession(dto.UserName, dto.LoginTime, dto.Machine);
            return Ok(new SessionStartResponse { SessionId = id });
        }

        [HttpPost, Route("session/end")]
        public IHttpActionResult EndSession([FromBody] SessionEndDto dto)
        {
            if (dto == null || dto.SessionId <= 0)
                return BadRequest("Geçerli SessionId gerekli.");

            _sessions.EndSession(dto.SessionId, dto.LogoutTime);
            return Ok(new { ok = true });
        }
    }
}
