using System;
using System.Net;
using System.Web.Http;
using ActivityTracker.Backend.Auth;
using ActivityTracker.Backend.Reports;
using ActivityTracker.Data.Repositories;
using ActivityTracker.Data.Security;
using ActivityTracker.Domain.Api;
using ActivityTracker.Domain.Enums;
using ActivityTracker.Domain.Models;

namespace ActivityTracker.Backend.Controllers
{
    /// <summary>Yönetici görünümü: tüm kullanıcıların verisi (Admin rolü gerekir).</summary>
    [TokenAuthorize(RequireAdmin = true)]
    [RoutePrefix("api/admin")]
    public class AdminController : ApiController
    {
        private readonly EventRepository _events = new EventRepository();
        private readonly UserRepository _users = new UserRepository();
        private readonly ReportService _reports =
            new ReportService(new EventRepository(), new UserRepository());

        [HttpGet, Route("users")]
        public IHttpActionResult Users()
        {
            return Ok(_reports.UserSummaries());
        }

        /// <summary>Yeni giriş hesabı oluşturur.</summary>
        [HttpPost, Route("users")]
        public IHttpActionResult CreateUser([FromBody] CreateUserRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.Username))
                return BadRequest("Kullanıcı adı gerekli.");
            if (string.IsNullOrEmpty(request.Password))
                return BadRequest("Parola gerekli.");

            var username = request.Username.Trim();
            if (_users.GetByUsername(username) != null)
                return Content(HttpStatusCode.Conflict, "Bu kullanıcı adı zaten var.");

            var role = string.Equals(request.Role, "Admin", StringComparison.OrdinalIgnoreCase)
                ? UserRole.Admin : UserRole.User;

            PasswordHasher.CreateHash(request.Password, out var hash, out var salt);
            _users.Add(new User
            {
                Username = username,
                DisplayName = string.IsNullOrWhiteSpace(request.DisplayName) ? username : request.DisplayName.Trim(),
                PasswordHash = hash,
                PasswordSalt = salt,
                Role = role,
                CreatedAt = DateTime.Now
            });
            return Ok(new { created = username });
        }

        /// <summary>Bir giriş hesabını siler (kendini ve son yöneticiyi koruyarak).</summary>
        [HttpDelete, Route("users/{user}")]
        public IHttpActionResult DeleteUser(string user)
        {
            if (string.IsNullOrWhiteSpace(user))
                return BadRequest("Kullanıcı gerekli.");

            if (string.Equals(user, this.CurrentUser(), StringComparison.OrdinalIgnoreCase))
                return Content(HttpStatusCode.Forbidden, "Kendi hesabınızı silemezsiniz.");

            var target = _users.GetByUsername(user);
            if (target == null)
                return Content(HttpStatusCode.NotFound, "Kullanıcı bulunamadı.");

            if (target.Role == UserRole.Admin && _users.CountByRole(UserRole.Admin) <= 1)
                return Content(HttpStatusCode.Forbidden, "Son yönetici hesabı silinemez.");

            _users.Delete(user);
            return Ok(new { deleted = user });
        }

        [HttpGet, Route("users/{user}/report")]
        public IHttpActionResult UserReport(string user, string date = null)
        {
            return Ok(_reports.DailyReport(user, DateArg.Parse(date)));
        }

        [HttpGet, Route("users/{user}/events")]
        public IHttpActionResult UserEvents(string user, string date = null)
        {
            return Ok(_reports.Events(user, DateArg.Parse(date)));
        }

        [HttpGet, Route("users/{user}/week")]
        public IHttpActionResult UserWeek(string user, string date = null)
        {
            return Ok(_reports.Week(user, DateArg.Parse(date)));
        }

        /// <summary>Seçili güne ait tüm kullanıcıların ham olayları.</summary>
        [HttpGet, Route("events")]
        public IHttpActionResult AllEvents(string date = null)
        {
            return Ok(_events.GetByDateAllUsers(DateArg.Parse(date)));
        }
    }
}
