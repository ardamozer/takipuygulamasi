using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace ActivityTracker.Backend.Auth
{
    /// <summary>
    /// Agent ingest uçları için X-Agent-Key başlığını paylaşılan anahtarla doğrular.
    /// </summary>
    public class AgentKeyAttribute : AuthorizationFilterAttribute
    {
        public const string HeaderName = "X-Agent-Key";

        public override void OnAuthorization(HttpActionContext actionContext)
        {
            string provided = null;
            if (actionContext.Request.Headers.TryGetValues(HeaderName, out var values))
                provided = values.FirstOrDefault();

            if (string.IsNullOrEmpty(provided) || provided != BackendConfig.AgentApiKey)
            {
                actionContext.Response = actionContext.Request.CreateErrorResponse(
                    HttpStatusCode.Unauthorized, "Geçersiz agent anahtarı.");
            }
        }
    }
}
