using System.Web.Http;
using ActivityTracker.Domain.Enums;

namespace ActivityTracker.Backend.Auth
{
    /// <summary>Controller içinden doğrulanmış kullanıcıyı okumak için yardımcılar.</summary>
    public static class AuthContext
    {
        public static string CurrentUser(this ApiController controller)
        {
            return controller.Request.Properties.TryGetValue(TokenAuthorizeAttribute.UserKey, out var v)
                ? v as string : null;
        }

        public static UserRole CurrentRole(this ApiController controller)
        {
            return controller.Request.Properties.TryGetValue(TokenAuthorizeAttribute.RoleKey, out var v) && v is UserRole role
                ? role : UserRole.User;
        }
    }
}
