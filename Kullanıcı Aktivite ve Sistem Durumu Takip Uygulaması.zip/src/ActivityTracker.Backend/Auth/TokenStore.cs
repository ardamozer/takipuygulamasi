using System;
using System.Collections.Concurrent;
using ActivityTracker.Domain.Enums;

namespace ActivityTracker.Backend.Auth
{
    /// <summary>Bir oturum jetonunun arkasındaki kimlik bilgisi.</summary>
    public class TokenInfo
    {
        public string Username { get; set; }
        public UserRole Role { get; set; }
        public DateTime Expiry { get; set; }
    }

    /// <summary>
    /// Bellek içi jeton deposu. Login'de jeton üretir, isteklerde doğrular.
    /// (Tek süreçli backend için yeterli; yeniden başlatınca jetonlar düşer.)
    /// </summary>
    public static class TokenStore
    {
        private static readonly ConcurrentDictionary<string, TokenInfo> Tokens =
            new ConcurrentDictionary<string, TokenInfo>();

        public static string Issue(string username, UserRole role)
        {
            var token = Guid.NewGuid().ToString("N");
            Tokens[token] = new TokenInfo
            {
                Username = username,
                Role = role,
                Expiry = DateTime.UtcNow.Add(BackendConfig.TokenLifetime)
            };
            return token;
        }

        /// <summary>Jeton geçerliyse bilgisini döner; değilse null.</summary>
        public static TokenInfo Validate(string token)
        {
            if (string.IsNullOrEmpty(token)) return null;
            if (!Tokens.TryGetValue(token, out var info)) return null;
            if (info.Expiry <= DateTime.UtcNow)
            {
                Tokens.TryRemove(token, out _);
                return null;
            }
            return info;
        }

        public static void Revoke(string token)
        {
            if (!string.IsNullOrEmpty(token))
                Tokens.TryRemove(token, out _);
        }
    }
}
