using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using ActivityTracker.Domain.Enums;

namespace ActivityTracker.Backend.Auth
{
    /// <summary>
    /// Authorization: Bearer &lt;token&gt; başlığını doğrular. Geçerliyse kullanıcı adı +
    /// rolü istek özelliklerine yazar. RequireAdmin=true ise yalnızca yöneticiye izin verir.
    /// </summary>
    public class TokenAuthorizeAttribute : AuthorizationFilterAttribute
    {
        public const string UserKey = "auth:user";
        public const string RoleKey = "auth:role";

        public bool RequireAdmin { get; set; }

        public override void OnAuthorization(HttpActionContext actionContext)
        {
            var auth = actionContext.Request.Headers.Authorization;
            var token = (auth != null && auth.Scheme == "Bearer") ? auth.Parameter : null;

            var info = TokenStore.Validate(token);
            if (info == null)
            {
                actionContext.Response = actionContext.Request.CreateErrorResponse(
                    HttpStatusCode.Unauthorized, "Geçersiz veya süresi dolmuş oturum.");
                return;
            }

            if (RequireAdmin && info.Role != UserRole.Admin)
            {
                actionContext.Response = actionContext.Request.CreateErrorResponse(
                    HttpStatusCode.Forbidden, "Bu işlem için yönetici yetkisi gerekir.");
                return;
            }

            actionContext.Request.Properties[UserKey] = info.Username;
            actionContext.Request.Properties[RoleKey] = info.Role;
        }
    }
}
