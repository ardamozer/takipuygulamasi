<#
  Hetabil - kilitli kurulum (YONETICI gerektirir).
  Kur.bat tarafindan cagrilir; yonetici degilse kendini UAC ile yukseltir.

  Yaptiklari:
   1. Agent ve Panel'i "C:\Program Files\Hetabil..." altina kopyalar.
      (Program Files izinleri geregi normal kullanici bu dosyalari silemez.)
   2. Agent icin oturum-acilista, en yuksek ayricalikla calisan, IZLENEN
      kullaniciya bagli bir Gorev Zamanlayici gorevi olusturur. Gorev admin
      tarafindan olusturuldugu icin normal kullanici onu kaldiramaz, yani
      "Windows ile baslat"i kapatamaz.

  $Kaynak verilmezse scriptin bulundugu klasor (paket klasoru) kullanilir;
  orada Agent\ ve Panel\ alt klasorleri bulunur.
#>
param(
    [Parameter(Mandatory = $true)][string]$Kullanici,   # DOMAIN\Kullanici (izlenecek kisi)
    [string]$Kaynak = $PSScriptRoot
)

$ErrorActionPreference = 'Stop'

# --- Yonetici degilsek kendimizi yukselt ve bitmesini bekle ---
$kimlik = [Security.Principal.WindowsIdentity]::GetCurrent()
$rol = New-Object Security.Principal.WindowsPrincipal($kimlik)
if (-not $rol.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    try {
        $p = Start-Process -Verb RunAs -Wait -PassThru -FilePath 'powershell.exe' -ArgumentList @(
            '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"",
            '-Kullanici', "`"$Kullanici`"", '-Kaynak', "`"$Kaynak`""
        )
        exit $p.ExitCode
    }
    catch {
        # UAC iptal edildi.
        exit 1
    }
}

# --- Buradan asagisi YONETICI olarak calisir ---

$agentHedef = Join-Path $env:ProgramFiles 'HetabilAgent'
$panelHedef = Join-Path $env:ProgramFiles 'HetabilPanel'
$agentExe   = Join-Path $agentHedef 'HetabilActivityAgent.exe'

# 1) Program Files'a kopyala
New-Item -ItemType Directory -Force -Path $agentHedef | Out-Null
New-Item -ItemType Directory -Force -Path $panelHedef | Out-Null
Copy-Item -Path (Join-Path $Kaynak 'Agent\*') -Destination $agentHedef -Recurse -Force
Copy-Item -Path (Join-Path $Kaynak 'Panel\*') -Destination $panelHedef -Recurse -Force

# 2) Oturum-acilis gorevi (XML; parola gerektirmez, InteractiveToken)
$xml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>Hetabil Aktivite Takip Agent - oturum acilista baslar</Description>
  </RegistrationInfo>
  <Triggers>
    <LogonTrigger>
      <Enabled>true</Enabled>
      <UserId>$Kullanici</UserId>
    </LogonTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>$Kullanici</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings>
      <StopOnIdleEnd>false</StopOnIdleEnd>
      <RestartOnIdle>false</RestartOnIdle>
    </IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <Priority>7</Priority>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>$agentExe</Command>
    </Exec>
  </Actions>
</Task>
"@

$xmlYol = Join-Path $env:TEMP 'HetabilAgentGorev.xml'
[System.IO.File]::WriteAllText($xmlYol, $xml, [System.Text.Encoding]::Unicode)   # schtasks Unicode bekler

schtasks /Create /TN "Hetabil Agent" /XML "$xmlYol" /F | Out-Null
$kod = $LASTEXITCODE
Remove-Item $xmlYol -Force -ErrorAction SilentlyContinue

if ($kod -ne 0) {
    Write-Host "HATA: Gorev olusturulamadi (schtasks cikis kodu $kod)."
    exit $kod
}

Write-Host "Kilitli kurulum tamam. Agent: $agentExe  (gorev: 'Hetabil Agent')."
exit 0
