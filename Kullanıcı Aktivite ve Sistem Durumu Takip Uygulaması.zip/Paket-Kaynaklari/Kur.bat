@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Hetabil Agent + Panel - Kurulum

rem ============================================================
rem  Bu script KARSI tarafin bilgisayarinda calisir.
rem  - Agent/Panel'i backend'e baglayan yapilandirmayi yazar.
rem  - Yonetici onayi ile Agent'i "C:\Program Files" altina kurar ve
rem    oturum-acilista calisan KILITLI bir gorev olusturur (normal
rem    kullanici otomatik baslatmayi kapatamaz / dosyalari silemez).
rem  - Masaustu kisayollarini olusturur.
rem ============================================================

rem Backend ile paylasilan anahtar (backend'de farkliysa burayi degistir):
set "AGENTKEY=hetabil-agent-key"
set "PORT=5005"

echo ============================================================
echo  Hetabil Aktivite Takip - Agent + Panel Kurulumu
echo ============================================================
echo.
echo Backend'in calistigi bilgisayarin IP adresini girin.
echo (O bilgisayarda komut isteminde "ipconfig" yazip IPv4 adresine bakin,
echo  ornek: 192.168.1.40)
echo.
set /p "IP=Backend IP adresi: "

if "%IP%"=="" ( echo IP bos olamaz! & pause & exit /b 1 )

set "URL=http://%IP%:%PORT%"

echo.
echo Yapilandirma yaziliyor (%URL%)...

rem --- agent.ini (kullaniciya ozel) ---
if not exist "%APPDATA%\HetabilAgent" md "%APPDATA%\HetabilAgent"
> "%APPDATA%\HetabilAgent\agent.ini" echo # Hetabil Agent yapilandirmasi
>>"%APPDATA%\HetabilAgent\agent.ini" echo BackendUrl=%URL%
>>"%APPDATA%\HetabilAgent\agent.ini" echo AgentApiKey=%AGENTKEY%
>>"%APPDATA%\HetabilAgent\agent.ini" echo IdleThresholdSeconds=60

rem --- panel.ini ---
if not exist "%APPDATA%\HetabilPanel" md "%APPDATA%\HetabilPanel"
> "%APPDATA%\HetabilPanel\panel.ini" echo BackendUrl=%URL%

rem --- Izlenecek kullanici (yukseltmeden ONCE yakala) ---
set "IZLENEN=%USERDOMAIN%\%USERNAME%"

echo.
echo Agent "Program Files" altina kuruluyor ve otomatik baslatma (kilitli)
echo ayarlaniyor. Birazdan YONETICI izni (UAC) istenecek...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Kur-Kilit.ps1" -Kullanici "%IZLENEN%"
set "KILITKOD=%ERRORLEVEL%"

if not "%KILITKOD%"=="0" (
    echo.
    echo UYARI: Kilitli kurulum tamamlanamadi ^(yonetici izni verilmedi veya hata^).
    echo        Agent yine calisir ama otomatik baslatma KILITLI olmaz.
    echo.
)

echo Masaustu kisayollari olusturuluyor...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell;" ^
  "$pf = [Environment]::GetFolderPath('ProgramFiles');" ^
  "$ico = Join-Path '%~dp0' 'hetabil.ico';" ^
  "$desk = [Environment]::GetFolderPath('Desktop');" ^
  "function K($ad,$hedef,$aciklama){" ^
  "  $s=$ws.CreateShortcut((Join-Path $desk $ad));" ^
  "  $s.TargetPath=$hedef; $s.WorkingDirectory=(Split-Path $hedef);" ^
  "  $s.IconLocation=$ico; $s.Description=$aciklama; $s.Save();" ^
  "}" ^
  "K 'Hetabil Agent.lnk' (Join-Path $pf 'HetabilAgent\HetabilActivityAgent.exe') 'Hetabil Agent';" ^
  "K 'Hetabil Panel.lnk' (Join-Path $pf 'HetabilPanel\HetabilActivityTracker.exe') 'Hetabil Panel';"

echo.
echo ============================================================
echo  Kurulum tamam!
echo  Masaustunde olustu:
echo    - Hetabil Agent  (acin: arka planda veri toplamaya baslar)
echo    - Hetabil Panel  (kendi loglarinizi gormek icin giris yapin)
echo.
if "%KILITKOD%"=="0" (
  echo  Otomatik baslatma KILITLI kuruldu: Windows acilisinda baslar ve
  echo  normal kullanici yonetici olmadan kapatamaz.
)
echo.
echo  Panel girisi icin yoneticiden kullanici adi/parola isteyin.
echo  (Kullanici adiniz Windows kullanici adinizla ayni olmalidir.)
echo ============================================================
pause
